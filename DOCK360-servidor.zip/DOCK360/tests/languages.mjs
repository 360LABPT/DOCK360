import assert from 'node:assert/strict';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import os from 'node:os';import path from 'node:path';
const manifest=JSON.parse(await readFile('dist/locales/manifest.json','utf8'));
assert.equal(manifest.languages.length,7);
for(const l of manifest.languages){const p=JSON.parse(await readFile('dist/locales/'+l.id+'.json','utf8'));assert.equal(p.id,l.id);assert.ok(Object.keys(p.messages).length>400);for(const[k,v]of Object.entries(p.messages)){const tokens=s=>[...s.matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort();assert.deepEqual(tokens(k),tokens(v),l.id+': '+k)}assert.ok(new Intl.DateTimeFormat(p.locale).format(new Date()));}
const tmp=await mkdtemp(path.join(os.tmpdir(),'dock360-language-')),port=3699;
const processServer=spawn(process.execPath,['server/server.mjs'],{env:{...process.env,PORT:String(port),DOCK_DATA_ROOT:tmp+'/config',DOCK_HOMES_ROOT:tmp+'/homes',DOCK_PRIVILEGED_HELPER:'0',DOCK_ADMIN_PASSWORD:'language-admin-password-123'},stdio:['ignore','pipe','pipe']});
const req=async(url,b,cookie,origin)=>{const r=await fetch('http://127.0.0.1:'+port+url,{method:b?'POST':'GET',headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...(origin?{Origin:origin}:{})},body:b?JSON.stringify(b):undefined});return{status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]}};
try{
 for(let i=0;i<80;i++){try{if((await req('/api/health')).status===200)break}catch{}await new Promise(r=>setTimeout(r,50))}
 for(const l of manifest.languages)assert.equal((await req('/locales/'+l.id+'.json')).status,200,'static pack on real server');
 assert.equal((await req('/api/locale')).status,401);assert.equal((await req('/api/languages')).status,401);
 const admin=(await req('/api/login',{username:'admin',password:'language-admin-password-123'})).cookie;assert.ok(admin);
 assert.equal((await req('/api/locale',null,admin)).data.configured,false);
 assert.equal((await req('/api/locale',{language:'de',timezone:'Europe/Berlin'},admin)).status,200);
 assert.equal((await req('/api/locale',null,admin)).data.language,'de');
 assert.equal((await req('/api/locale',{language:'de',timezone:'Wrong/Zone'},admin)).status,400);
 assert.equal((await req('/api/locale',{language:'xx',timezone:'auto'},admin)).status,400);
 assert.equal((await req('/api/locale',{language:'fr',timezone:'auto'},admin,'https://evil.example')).status,403);
 await req('/api/users',{username:'alice',role:'viewer',password:'alice-language-password'},admin);
 const alice=(await req('/api/login',{username:'alice',password:'alice-language-password'})).cookie;
 assert.equal((await req('/api/locale',null,alice)).data.configured,false);await req('/api/locale',{language:'es',timezone:'America/Mexico_City'},alice);
 assert.equal((await req('/api/locale',null,admin)).data.language,'de');assert.equal((await req('/api/locale',null,alice)).data.language,'es');
 const pack={id:'nl',name:'Nederlands',locale:'nl-NL',direction:'ltr',messages:{Idioma:'Taal','Início':'Start','{count} aplicações encontradas':'{count} apps gevonden'}};
 assert.equal((await req('/api/languages',pack,alice)).status,403);assert.equal((await req('/api/languages',pack,admin)).status,200);
 assert.equal((await req('/api/languages',null,alice)).data.languages.length,8);
 assert.equal((await req('/api/language-pack?id=nl',null,alice)).data.messages.Idioma,'Taal');
 assert.equal((await req('/api/locale',{language:'nl',timezone:'auto'},alice)).status,200);
 assert.equal((await req('/api/language-pack?id=../users',null,admin)).status,400);
 assert.equal((await req('/api/languages',{...pack,id:'en'},admin)).status,400);
 assert.equal((await req('/api/languages',{...pack,messages:{Idioma:'<script>alert(1)</script>'}},admin)).status,400);
 assert.equal((await req('/api/languages',{...pack,messages:{'{count} aplicações encontradas':'apps'}},admin)).status,400);
 assert.equal((await req('/api/languages',{...pack,locale:null},admin)).status,400);
 const json=await readFile(tmp+'/config/languages/nl.json','utf8');assert.equal(JSON.parse(json).id,'nl');
 assert.equal(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(new Date('2026-10-22T00:00:00Z')),'09');
 console.log('PASS: seven offline packs, placeholder parity, real static delivery, per-user region isolation, timezone validation, CSRF, administrator-only pack installation, persistent JSON packs, no builtin override, HTML rejection and traversal protection.');
}finally{processServer.kill();await new Promise(r=>processServer.once('exit',r));await rm(tmp,{recursive:true,force:true})}
