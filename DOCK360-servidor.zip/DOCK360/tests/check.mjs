// Canonical HTTP checks for the current access model.
await import('./security-v04.mjs');
