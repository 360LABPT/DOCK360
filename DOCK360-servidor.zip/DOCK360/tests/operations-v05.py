import importlib.util,tempfile,pathlib,os,json,tarfile,io,hashlib,types,zipfile,stat
spec=importlib.util.spec_from_file_location('services','privileged/36odock-services.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
with tempfile.TemporaryDirectory() as tmp:
 root=pathlib.Path(tmp);s.configure(root/'config',root/'homes');s.MOUNTS=root/'mounts';s.INSTALL=root/'install'
 (root/'config').mkdir();(root/'config/users.json').write_text('[{"username":"admin","role":"admin"}]');(root/'homes').mkdir();(root/'homes/data.txt').write_text('private');(root/'teams').mkdir()
 rows={'blockdevices':[{'name':'/dev/mmcblk0','type':'disk','size':64000,'children':[{'name':'/dev/mmcblk0p1','type':'part','mountpoints':['/'],'uuid':'root-uuid','fstype':'ext4'}]},{'name':'/dev/sda','type':'disk','size':1000000,'tran':'usb','children':[{'name':'/dev/sda1','type':'part','size':999000,'fstype':'ext4','uuid':'data-uuid','mountpoints':[],'ro':False}]}]}
 rows['blockdevices'].append({'name':'/dev/nvme1n1','type':'disk','tran':'nvme','children':[{'name':'/dev/nvme1n1p1','type':'part','size':1000000,'uuid':'ssd-data','fstype':'ext4','mountpoints':[],'ro':False}]})
 calls=[]
 def run(args,timeout=60,check=True):
  args=list(map(str,args));calls.append(args)
  if args[0]=='/usr/bin/lsblk':return json.dumps(rows)
  if args[:3]==['/bin/systemctl','is-active','smbd.service']:return 'active'
  return ''
 s.run=run
 disks=s.disk_rows();assert next(d for d in disks if d['uuid']=='ssd-data')['manageable'];assert not next(d for d in disks if d['uuid']=='root-uuid')['manageable'];assert next(d for d in disks if d['uuid']=='data-uuid')['manageable']
 try:s.disk({'action':'mount','uuid':'root-uuid'});raise AssertionError('System disk mounted')
 except s.OperationError:pass
 s.disk({'action':'mount','uuid':'data-uuid'});assert any(a[0]=='/bin/mount' and 'nosuid,nodev,noexec' in a for a in calls)
 c=[{'Id':'managed','State':{'Running':True},'Name':'/36odock-demo','Config':{'Image':'demo:1'},'Mounts':[]}]
 s.managed_containers=lambda:c;s.managed_volumes=lambda c:[]
 result=s.backup_create('a'*32);archive=root/'backups'/result['id'];assert archive.exists();assert stat.S_IMODE(archive.stat().st_mode)==0o600;assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['sha256']
 assert any(a[:2]==['/usr/bin/docker','stop'] for a in calls);assert any(a[:2]==['/usr/bin/docker','start'] for a in calls);assert any(a[:3]==['/bin/systemctl','start','smbd.service'] for a in calls)
 assert s.backup_list()['backups'][0]['id']==result['id']
 with tarfile.open(archive) as t:assert s.validate_backup(t)['format']==1
 # Actual file restore with all system calls replaced by the fixed mock above.
 s.health=lambda:None;s.sync_teams=lambda broker:None
 def account(name):
  home=s.ROOT/'homes'/'admin';home.mkdir(exist_ok=True);return types.SimpleNamespace(pw_uid=os.getuid(),pw_gid=os.getgid()),home
 s.load_broker=lambda:types.SimpleNamespace(account=account,samba=lambda b:None)
 (root/'homes/data.txt').write_text('changed')
 restored=s.backup_restore({'id':result['id'],'confirm':'RESTAURAR'},'c'*32);assert restored['restored']==result['id'];assert (root/'homes/data.txt').read_text()=='private'
 # A health failure must put the pre-restore data back.
 (root/'homes/data.txt').write_text('latest')
 def unhealthy():raise s.OperationError('health failed')
 s.health=unhealthy
 try:s.backup_restore({'id':result['id'],'confirm':'RESTAURAR'},'d'*32);raise AssertionError('health failure ignored')
 except s.OperationError:pass
 assert (root/'homes/data.txt').read_text()=='latest';s.health=lambda:None
 # Interrupt archival after services stop; every originally running service must restart.
 old_open=s.tarfile.open
 def broken(*a,**kw):raise OSError('disk full')
 s.tarfile.open=broken;calls.clear()
 try:s.backup_create('b'*32);raise AssertionError('failure ignored')
 except OSError:pass
 assert any(a[:2]==['/usr/bin/docker','start'] for a in calls);assert any(a[:3]==['/bin/systemctl','start','smbd.service'] for a in calls);s.tarfile.open=old_open
 for name,kind,link in [('../outside',tarfile.REGTYPE,''),('/etc/passwd',tarfile.REGTYPE,''),('homes/escape',tarfile.SYMTYPE,'/etc'),('homes/fifo',tarfile.FIFOTYPE,'')]:
  memory=io.BytesIO()
  with tarfile.open(fileobj=memory,mode='w') as t:
   m=tarfile.TarInfo(name);m.type=kind;m.linkname=link;t.addfile(m)
  memory.seek(0)
  with tarfile.open(fileobj=memory) as t:
   try:s.validate_backup(t);raise AssertionError(name)
   except s.OperationError:pass
 for url in ['http://github.com/x/y','https://evil.com/x.zip','https://github.com.evil.com/x','https://user:pass@github.com/a','https://github.com:8443/a']:
  try:s.checked_url(url);raise AssertionError(url)
  except s.OperationError:pass
 assert s.checked_url('https://github.com/a/b/releases/download/v1/app.zip')
 # Update and rollback activate real symlinks in a temporary install tree only.
 s.LIBEXEC=root/'libexec';s.LIBEXEC.mkdir();(s.INSTALL/'releases/old/server').mkdir(parents=True);(s.INSTALL/'releases/old/server/server.mjs').write_text('// old');(s.INSTALL/'current').symlink_to(s.INSTALL/'releases/old');(s.INSTALL/'port').write_text('3600');s.JOBS.mkdir(exist_ok=True)
 for n in ['36odock-admin','36odock-services.py','36odock-pty.py']:(s.LIBEXEC/n).write_text('old-helper')
 package=io.BytesIO()
 with zipfile.ZipFile(package,'w') as z:
  for n in ['server/server.mjs','dist/index.html','privileged/36odock-admin.py','privileged/36odock-services.py','privileged/36odock-pty.py']:z.writestr('DOCK360/'+n,'new-helper')
  z.writestr('DOCK360/dist/version.json','{"version":"0.6.0"}')
 payload=package.getvalue();release={'version':'0.6.0','sha256':hashlib.sha256(payload).hexdigest(),'packageUrl':'https://github.com/test/DOCK360/releases/download/v0.6.0/app.zip'}
 s.urllib.request.build_opener=lambda *a:types.SimpleNamespace(open=lambda *a,**kw:io.BytesIO(payload));backups=[];s.backup_create=lambda job:backups.append(job)
 s.health=unhealthy
 try:s.update_install({'release':release},'e'*32);raise AssertionError('health failure ignored')
 except s.OperationError:pass
 assert (s.INSTALL/'current').resolve()==s.INSTALL/'releases/old';assert (s.LIBEXEC/'36odock-admin').read_text()=='old-helper';assert backups==['e'*32]
 s.health=lambda:None;s.update_install({'release':release},'f'*32)
 assert (s.INSTALL/'current').resolve()!=s.INSTALL/'releases/old';assert (s.LIBEXEC/'36odock-admin').read_text()=='new-helper';assert s.rollback_release()['rolledBack'];assert (s.INSTALL/'current').resolve()==s.INSTALL/'releases/old'
 bad={**release,'sha256':'0'*64}
 try:s.update_install({'release':bad},'1'*32);raise AssertionError('corrupt update accepted')
 except s.OperationError:pass
 assert (s.INSTALL/'current').resolve()==s.INSTALL/'releases/old'
 # An absent external disk must never silently write to the SD card.
 s.write_json(root/'backup-destination.json',{'uuid':'missing-disk'})
 try:s.backup_dir();raise AssertionError('Missing disk fallback')
 except s.OperationError:pass
 print('PASS: system disk protection, fixed mount options, backup archive and SHA256, container/Samba restart, real file restore and rollback on health failure, unsafe archive paths/links/devices, HTTPS GitHub source restrictions, update activation/health rollback/helper recovery, checksum rejection and missing external disk failure (system commands mocked).')
