import importlib.util,tempfile,pathlib,os,types,base64,hashlib,subprocess,json,time,select
spec=importlib.util.spec_from_file_location('helper','privileged/36odock-admin.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
with tempfile.TemporaryDirectory() as d:
 root=pathlib.Path(d);home=root/'home';home.mkdir();outside=root/'outside';outside.mkdir();(outside/'secret').write_text('secret')
 user=types.SimpleNamespace(pw_uid=os.getuid(),pw_gid=os.getgid(),pw_name='test_user',pw_dir=str(home))
 h.account=lambda username:(user,home)
 def call(op,**kw):return h.files({'op':op,'username':'alice','scope':'private',**kw})
 call('mkdir',path='Documents');call('upload',path='Documents/test.txt',content=base64.b64encode(b'original').decode());assert call('download',path='Documents/test.txt')['content']==base64.b64encode(b'original').decode()
 assert os.stat(home/'Documents').st_mode&0o777==0o700;assert os.stat(home/'Documents/test.txt').st_mode&0o777==0o600
 (home/'escape').symlink_to(outside,target_is_directory=True)
 try:call('list',path='escape');raise AssertionError('symlink accepted')
 except OSError:pass
 try:call('download',path='../outside/secret');raise AssertionError('traversal accepted')
 except h.Fault:pass
 call('upload',path='Documents/existing.txt',content='Yg==')
 try:call('rename',path='Documents/test.txt',name='existing.txt');raise AssertionError('overwrite accepted')
 except FileExistsError:pass
 assert (home/'Documents/existing.txt').read_text()=='b'
 call('write',path='Documents/test.txt',content=base64.b64encode(b'updated').decode(),expectedHash=hashlib.sha256(b'original').hexdigest())
 try:call('write',path='Documents/test.txt',content='Yg==',expectedHash='wrong');raise AssertionError('stale edit accepted')
 except h.Fault as e:assert e.status==409
 h.DATA=root/'config';h.DATA.mkdir();(h.DATA/'users.json').write_text(json.dumps([{'username':'alice'}]));config=h.samba_config();assert 'valid users = test_user' in config;assert 'guest ok = no' in config;assert 'follow symlinks = no' in config
 calls=[];h.run=lambda a,stdin=None:calls.append(a) or '';assert h.dispatch({'op':'reboot'})=={'scheduled':True};assert calls[-1][-1]=='reboot' # mocked; never executed
 assert h.name_for('Alice')!=h.name_for('alice')
 print('PASS: broker file permissions, no-follow paths, traversal rejection, non-overwriting rename, conflict detection, private Samba configuration and reboot scheduling (mocked).')
# The PTY bridge is tested independently with harmless shell output; no system action.
p=subprocess.Popen(['python3','privileged/36odock-pty.py'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
p.stdin.write(json.dumps({'op':'resize','rows':30,'cols':100})+'\n');p.stdin.write(json.dumps({'op':'write','data':base64.b64encode(b"printf 'DOCK_PTY_OK\\n'\rexit\r").decode()})+'\n');p.stdin.flush()
output='';deadline=time.monotonic()+8
while time.monotonic()<deadline:
 ready,_,_=select.select([p.stdout],[],[],.5)
 if ready:
  line=p.stdout.readline()
  if not line:break
  packet=json.loads(line)
  if packet.get('data'):output+=base64.b64decode(packet['data']).decode(errors='replace')
  if packet.get('exit'):break
p.stdin.close();p.wait(timeout=5);assert 'DOCK_PTY_OK' in output;print('PASS: real PTY, shell output, resize and clean exit.')
