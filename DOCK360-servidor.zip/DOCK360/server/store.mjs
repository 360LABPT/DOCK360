import {mkdir,readFile,writeFile,rename,appendFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
export const dataRoot=path.resolve(process.env.DOCK_DATA_ROOT||new URL('../data/',import.meta.url).pathname);
await mkdir(dataRoot,{recursive:true,mode:0o750});
export const fail=(message,status=400)=>{throw Object.assign(Error(message),{status})};
export async function readJSON(name,fallback){try{return JSON.parse(await readFile(path.join(dataRoot,name),'utf8'))}catch(e){if(e.code==='ENOENT')return structuredClone(fallback);throw e}}
export async function saveJSON(name,value){const tmp=path.join(dataRoot,'.'+name+'.'+randomBytes(8).toString('hex'));await writeFile(tmp,JSON.stringify(value),{mode:0o600});await rename(tmp,path.join(dataRoot,name))}
export async function body(req,limit=65536){let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>limit)fail('Pedido demasiado grande',413);chunks.push(c)}try{return JSON.parse(Buffer.concat(chunks).toString())}catch{fail('Pedido JSON inválido')}}
let auditQueue=Promise.resolve();
export function audit(user,event,detail=''){const row={time:new Date().toISOString(),user:typeof user==='string'?user:user?.username||'anónimo',event:String(event).slice(0,100),detail:String(detail).replace(/[\r\n\x00-\x1f]/g,' ').slice(0,240)};auditQueue=auditQueue.then(async()=>{const file=path.join(dataRoot,'activity.jsonl');try{if((await stat(file)).size>5e6)await rename(file,path.join(dataRoot,'activity.previous.jsonl'))}catch(e){if(e.code!=='ENOENT')throw e}await appendFile(file,JSON.stringify(row)+'\n',{mode:0o600})});auditQueue=auditQueue.catch(e=>console.error('Falha no registo de atividade:',e.message));return auditQueue}
export async function activity(){await auditQueue;let rows=[];for(const name of ['activity.previous.jsonl','activity.jsonl'])try{rows.push(...(await readFile(path.join(dataRoot,name),'utf8')).trim().split('\n').filter(Boolean).map(s=>JSON.parse(s)))}catch(e){if(e.code!=='ENOENT')throw e}return rows.slice(-1000).reverse()}

export async function maintenance(){try{const active=JSON.parse(await readFile(path.join(dataRoot,'../operations-active.json'),'utf8'));if(!Number.isInteger(active.pid)||!/^([a-f0-9]{32})$/.test(active.id))return true;try{const command=await readFile('/proc/'+active.pid+'/cmdline','utf8');return command.includes('--job\0'+active.id+'\0')}catch(e){return !['ENOENT','ESRCH'].includes(e.code)}}catch(e){if(e.code==='ENOENT')return false;return true}}
