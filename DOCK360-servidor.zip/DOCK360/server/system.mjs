import {audit} from './store.mjs';
import {hasHelper,privileged} from './privileged.mjs';
export async function systemRoute(req,res,url){
 const send=(s,d)=>{res.writeHead(s,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d))};
 try{
  const admin=req.user.role==='admin';
  if(url.pathname==='/api/system/status'&&req.method==='GET')return send(200,{privileged:admin&&hasHelper,systemFiles:admin&&hasHelper,terminal:admin&&hasHelper,samba:hasHelper});
  if(url.pathname==='/api/system/reboot'){
   if(!admin)return send(403,{error:'Só o administrador pode reiniciar o sistema'});
   if(req.method!=='POST')return send(405,{error:'Método não permitido'});
   let body='';for await(const c of req){body+=c;if(body.length>4096)return send(413,{error:'Pedido demasiado grande'})}
   if(JSON.parse(body).confirm!=='REINICIAR')return send(400,{error:'Confirme escrevendo REINICIAR'});
   const result=await privileged({op:'reboot'});await audit(req.user,'sistema.reinício');return send(200,result);
  }
  if(url.pathname==='/api/system/samba'){
   if(req.method==='GET')return send(200,await privileged({op:'samba',action:'status',username:req.user.username}));
   if(req.method!=='POST')return send(405,{error:'Método não permitido'});
   let body='';for await(const c of req){body+=c;if(body.length>4096)return send(413,{error:'Pedido demasiado grande'})}const b=JSON.parse(body);
   if(!['password','disable','sync'].includes(b.action))return send(400,{error:'Operação inválida'});
   if(b.action==='sync'&&!admin)return send(403,{error:'Só o administrador pode atualizar a configuração Samba'});
   return send(200,await privileged({op:'samba',action:b.action,username:req.user.username,password:b.password}));
  }
  send(404,{error:'Rota inexistente'});
 }catch(e){send(e.status||400,{error:e.message})}
}
