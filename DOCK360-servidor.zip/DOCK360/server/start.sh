#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo 'Instale Node.js 22 ou superior.'; exit 1; }
command -v docker >/dev/null || { echo 'Instale Docker Engine antes de continuar.'; exit 1; }
: "${DOCK_ADMIN_PASSWORD:=${DOCK_TOKEN:-}}"
export DOCK_ADMIN_PASSWORD
if [ ${#DOCK_ADMIN_PASSWORD} -lt 12 ]; then echo "Defina DOCK_ADMIN_PASSWORD com pelo menos 12 caracteres."; exit 1; fi
exec node server/server.mjs
