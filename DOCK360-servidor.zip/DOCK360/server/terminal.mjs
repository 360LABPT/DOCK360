import {audit} from './store.mjs';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {hasHelper,helperPath} from './privileged.mjs';
import {authEvents} from './auth.mjs';
const sessions=new Map();
function close(id){const t=sessions.get(id);if(!t)return;try{t.child.stdin.end(JSON.stringify({op:'close'})+'\n')}catch{}t.child.kill();sessions.delete(id)}
authEvents.on('sessionClosed',sid=>{for(const[id,t]of sessions)if(t.sessionId===sid)close(id)});
setInterval(()=>{for(const[id,t]of sessions)if(Date.now()-t.last>900000)close(id)},30000).unref();
export async function terminalRoute(req,res,url){const send=(s,d)=>{res.writeHead(s,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d))};try{
 if(req.user.role!=='admin')return send(403,{error:'Terminal reservado ao administrador'});
 if(!hasHelper)return send(503,{error:'Instale o pacote Raspberry Pi atualizado para ativar o terminal.'});
 if(req.method==='POST'&&req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(403,{error:'Origem inválida'});
 let b={};if(req.method==='POST'){let s='';for await(const c of req){s+=c;if(s.length>40000)return send(413,{error:'Pedido demasiado grande'})}b=JSON.parse(s)}
 if(url.pathname==='/api/terminal/open'&&req.method==='POST'){
  for(const[id,t]of sessions)if(t.sessionId===req.sessionId)close(id);
  if(sessions.size>=4)return send(409,{error:'Limite de terminais atingido'});
  const id=randomBytes(24).toString('hex'),child=spawn('sudo',['-n',helperPath,'terminal'],{stdio:['pipe','pipe','pipe']}),t={child,sessionId:req.sessionId,username:req.user.username,last:Date.now(),chunks:[],next:0,exited:false,buffer:''};sessions.set(id,t);
  child.stdout.on('data',block=>{t.buffer+=block.toString();if(t.buffer.length>2e6){close(id);return}let i;while((i=t.buffer.indexOf('\n'))>=0){let line=t.buffer.slice(0,i);t.buffer=t.buffer.slice(i+1);try{const d=JSON.parse(line);if(d.data){t.chunks.push({cursor:++t.next,data:d.data});if(t.chunks.length>128)t.chunks.shift()}if(d.exit)t.exited=true}catch{}}});child.stderr.on('data',()=>{});child.on('error',()=>{t.exited=true});child.on('exit',()=>{t.exited=true});child.stdin.on('error',()=>{});
  await audit(req.user,'terminal.aberto');return send(200,{id});
 }
 const id=req.method==='GET'?url.searchParams.get('id'):b.id,t=sessions.get(id);
 if(!t||t.sessionId!==req.sessionId||t.username!==req.user.username)return send(404,{error:'Terminal inexistente ou expirado'});
 if(url.pathname==='/api/terminal/read'&&req.method==='GET'){const cursor=Number(url.searchParams.get('cursor')||0);return send(200,{chunks:t.chunks.filter(c=>c.cursor>cursor),cursor:t.next,exited:t.exited})}
 if(url.pathname==='/api/terminal/close'&&req.method==='POST'){close(id);return send(200,{ok:true})}
 if(url.pathname==='/api/terminal/input'&&req.method==='POST'){
  if(b.op==='write'){if(typeof b.data!=='string'||b.data.length>30000)return send(400,{error:'Entrada inválida'});t.child.stdin.write(JSON.stringify({op:'write',data:b.data})+'\n')}
  else if(b.op==='resize'){if(!Number.isInteger(b.cols)||!Number.isInteger(b.rows)||b.cols<20||b.cols>400||b.rows<5||b.rows>150)return send(400,{error:'Dimensões inválidas'});t.child.stdin.write(JSON.stringify({op:'resize',cols:b.cols,rows:b.rows})+'\n')}
  else return send(400,{error:'Operação inválida'});t.last=Date.now();return send(200,{ok:true});
 }
 send(404,{error:'Rota inexistente'});
}catch{send(400,{error:'O terminal não conseguiu concluir o pedido'})}}
