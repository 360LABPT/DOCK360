import {EventEmitter} from 'node:events';
import {randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {hasHelper,privileged} from './privileged.mjs';
import {readJSON,saveJSON,body,audit,fail} from './store.mjs';
import {secret,verify,recoveryHash} from './totp.mjs';
export const authEvents=new EventEmitter();
const hash=(p,s)=>scryptSync(p,s,64).toString('hex');
let users=await readJSON('users.json',null);
if(!users){const p=process.env.DOCK_ADMIN_PASSWORD||process.env.DOCK_TOKEN,u=process.env.DOCK_ADMIN_USER||'admin';if(!p||p.length<12||p.length>256||!/^[a-zA-Z0-9_.-]{3,40}$/.test(u))throw Error('Configure credenciais iniciais válidas (palavra-passe: 12 a 256 caracteres).');const salt=randomBytes(16).toString('hex');users=[{username:u,salt,hash:hash(p,salt),role:'admin'}];await saveJSON('users.json',users)}
const sessions=new Map(),attempts=new Map(),enrollments=new Map();
const permissions={admin:['files.read','files.write','files.system','apps.manage','catalog.manage','users.manage','terminal','system.reboot'],manager:['files.read','files.write','apps.manage'],viewer:['files.read','files.write']};
export function permitted(req,p){return !!req.user&&permissions[req.user.role]?.includes(p)}
export const publicUsers=()=>users.map(({username,role})=>({username,role}));
export function authenticate(req){const sid=req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith('dock_session='))?.slice(13),s=sessions.get(sid);if(s&&s.expires>Date.now()){const u=users.find(u=>u.username===s.username);if(u){req.user={username:u.username,role:u.role,permissions:permissions[u.role],mfa:!!u.mfa};req.sessionId=sid;return true}}if(sid){sessions.delete(sid);authEvents.emit('sessionClosed',sid)}return false}
export function revoke(username,keep){for(const[k,s]of sessions)if(s.username===username&&k!==keep){sessions.delete(k);authEvents.emit('sessionClosed',k)}}
function passwordOK(u,p){if(typeof p!=='string'||p.length>256)return false;const digest=hash(p,u?.salt||'dummy-salt');return !!u&&timingSafeEqual(Buffer.from(digest,'hex'),Buffer.from(u.hash,'hex'))}
export function reauthenticate(req,password){if(!passwordOK(users.find(u=>u.username===req.user.username),password))fail('Confirme a sua palavra-passe atual',403)}
async function persist(next){await saveJSON('users.json',next);users=next}
let editing=false;
export async function authRoute(req,res,url){const send=(s,d)=>{res.writeHead(s,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d))};const cookie=(v,age)=>`dock_session=${v}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${process.env.DOCK_SECURE_COOKIE==='true'?'; Secure':''}`;
try{
 if(req.method==='POST'&&req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(403,{error:'Origem inválida'});
 if(url.pathname==='/api/login'&&req.method==='POST'){
  const key=req.socket.remoteAddress;let a=attempts.get(key);if(a&&a.until>Date.now()&&a.count>=5)return send(429,{error:'Demasiadas tentativas. Aguarde 15 minutos.'});const b=await body(req,8192),u=users.find(u=>u.username===b.username);let valid=passwordOK(u,b.password),step=null,recovery=-1;
  if(valid&&u.mfa){step=verify(u.mfa.secret,b.code,u.mfa.lastStep??-1);if(step===null&&typeof b.code==='string')recovery=(u.mfa.recovery||[]).indexOf(recoveryHash(b.code));valid=step!==null||recovery>=0}
  if(!valid){if(!a||a.until<Date.now())a={count:0,until:Date.now()+900000};a.count++;attempts.set(key,a);if(attempts.size>10000)for(const[k,v]of attempts)if(v.until<Date.now())attempts.delete(k);await audit('anónimo','login.recusado');return send(401,{error:u?.mfa&&passwordOK(u,b.password)?'Introduza um código do autenticador ou um código de recuperação válido.':'Utilizador ou palavra-passe incorretos'})}
  if(editing)return send(409,{error:'Alteração de conta em curso. Tente novamente.'});editing=true;try{if(u.mfa){let next=structuredClone(users),n=next.find(x=>x.username===u.username);if(step!==null)n.mfa.lastStep=step;else n.mfa.recovery.splice(recovery,1);await persist(next)}}finally{editing=false}
  attempts.delete(key);const sid=randomBytes(32).toString('hex');for(const[k,s]of sessions)if(s.expires<Date.now()){sessions.delete(k);authEvents.emit('sessionClosed',k)}sessions.set(sid,{username:u.username,expires:Date.now()+8*3600000});res.setHeader('Set-Cookie',cookie(sid,28800));await audit(u,'login.aceite');return send(200,{ok:true});
 }
 if(!authenticate(req))return send(401,{error:'Autenticação necessária'});
 if(url.pathname==='/api/me'&&req.method==='GET')return send(200,req.user);
 if(url.pathname==='/api/logout'&&req.method==='POST'){sessions.delete(req.sessionId);authEvents.emit('sessionClosed',req.sessionId);res.setHeader('Set-Cookie',cookie('',0));await audit(req.user,'logout');return send(200,{ok:true})}
 if(url.pathname==='/api/security'&&req.method==='GET'){const u=users.find(x=>x.username===req.user.username);return send(200,{mfa:!!u.mfa,recoveryRemaining:u.mfa?.recovery?.length||0,sessions:[...sessions.entries()].filter(([,s])=>s.username===u.username&&s.expires>Date.now()).map(([id,s])=>({id,current:id===req.sessionId,expires:new Date(s.expires).toISOString()}))})}
 if(url.pathname==='/api/users'&&!permitted(req,'users.manage'))return send(403,{error:'Apenas o administrador pode gerir contas'});
 if(url.pathname==='/api/users'&&req.method==='GET')return send(200,publicUsers());
 if(req.method!=='POST')return send(405,{error:'Método não permitido'});
 if(editing)return send(409,{error:'Outra alteração de contas está em curso'});editing=true;
 try{
  const b=await body(req,8192);
  if(url.pathname==='/api/security'){
   reauthenticate(req,b.password);const u=users.find(x=>x.username===req.user.username),next=structuredClone(users),n=next.find(x=>x.username===u.username);
   if(b.op==='enroll'){if(u.mfa)fail('A autenticação em dois fatores já está ativa',409);const key=secret();enrollments.set(u.username,{secret:key,expires:Date.now()+600000});await audit(req.user,'2fa.preparada');return send(200,{secret:key,uri:'otpauth://totp/'+encodeURIComponent('DOCK360:'+u.username)+'?secret='+key+'&issuer=DOCK360&algorithm=SHA1&digits=6&period=30'})}
   if(b.op==='confirm'){const p=enrollments.get(u.username);if(!p||p.expires<Date.now())fail('A configuração expirou. Inicie novamente.');const step=verify(p.secret,b.code);if(step===null)fail('Código inválido');const codes=Array.from({length:10},()=>randomBytes(8).toString('hex').toUpperCase());n.mfa={secret:p.secret,lastStep:step,recovery:codes.map(recoveryHash)};await persist(next);enrollments.delete(u.username);revoke(u.username,req.sessionId);await audit(req.user,'2fa.ativada');return send(200,{ok:true,recovery:codes})}
   if(b.op==='disable'){if(!u.mfa)fail('Dois fatores já desativados');const recovery=(u.mfa.recovery||[]).includes(recoveryHash(b.code));if(verify(u.mfa.secret,b.code,u.mfa.lastStep??-1)===null&&!recovery)fail('Código inválido ou já utilizado');delete n.mfa;await persist(next);revoke(u.username,req.sessionId)}
   else if(b.op==='password'){if(typeof b.nextPassword!=='string'||b.nextPassword.length<12||b.nextPassword.length>256)fail('Utilize 12 a 256 caracteres');n.salt=randomBytes(16).toString('hex');n.hash=hash(b.nextPassword,n.salt);await persist(next);revoke(u.username,req.sessionId)}
   else if(b.op==='revoke')revoke(u.username,req.sessionId);
   else fail('Operação inválida');await audit(req.user,'segurança.'+b.op);return send(200,{ok:true});
  }
  if(url.pathname!=='/api/users')return send(404,{error:'Rota inexistente'});
  if(!/^[a-zA-Z0-9_.-]{3,40}$/.test(b.username)||!permissions[b.role])return send(400,{error:'Utilizador ou perfil inválido'});let next=structuredClone(users);
  if(b.op==='delete'){if(b.username===req.user.username)return send(400,{error:'Não pode eliminar a sua própria conta'});if(hasHelper)await privileged({op:'samba',action:'disable',username:b.username});next=next.filter(u=>u.username!==b.username)}
  else{const existing=next.find(u=>u.username===b.username);if(existing?.role==='admin'&&b.role!=='admin'&&next.filter(u=>u.role==='admin').length===1)return send(400,{error:'Tem de manter pelo menos um administrador'});if((!existing||b.password)&&(typeof b.password!=='string'||b.password.length<12||b.password.length>256))return send(400,{error:'Utilize uma palavra-passe entre 12 e 256 caracteres'});const u=existing||{username:b.username};if(b.password){u.salt=randomBytes(16).toString('hex');u.hash=hash(b.password,u.salt)}u.role=b.role;if(!existing){if(hasHelper)await privileged({op:'provision',username:b.username});next.push(u)}}
  await persist(next);revoke(b.username);await audit(req.user,'conta.'+(b.op==='delete'?'eliminada':'guardada'),b.username);let warning;
  if(hasHelper)try{await privileged({op:'teams',action:'sync'})}catch{warning='Conta guardada. Atualize a configuração Samba em Definições.'}
  return send(200,{ok:true,warning});
 }finally{editing=false}
}catch(e){return send(e.status||400,{error:e.status?e.message:'Pedido inválido'})}}
