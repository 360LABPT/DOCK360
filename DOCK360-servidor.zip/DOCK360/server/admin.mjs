import {readFile} from 'node:fs/promises';
import {metrics} from './metrics.mjs';
import {hasHelper,privileged} from './privileged.mjs';
import {activity,readJSON,saveJSON,body,audit,fail} from './store.mjs';
import {reauthenticate} from './auth.mjs';
export const version=JSON.parse(await readFile(new URL('../dist/version.json',import.meta.url),'utf8'));
const github=url=>{try{const u=new URL(url);return u.protocol==='https:'&&u.hostname==='raw.githubusercontent.com'&&!u.username&&!u.password&&/^\/[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+\/[^/]+\/.+\.json$/.test(u.pathname)}catch{return false}};
let operation=false;
export async function adminRoute(req,res,url){const send=(s,d)=>{res.writeHead(s,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d))};try{
 const name=url.pathname.split('/').at(-1);
 if(name==='monitor'&&req.method==='GET')return send(200,await metrics());
 if(name==='setup'&&req.method==='GET')return send(200,await readJSON('setup.json',{completed:false,name:'DOCK360',latitude:null,longitude:null}));
 if(req.user.role!=='admin')fail('Só o administrador pode gerir o equipamento',403);
 if(req.method==='GET'){
  if(name==='activity')return send(200,{events:await activity()});
  if(name==='updates')return send(200,{current:version,...await readJSON('update-source.json',{feed:'',release:null}),helper:hasHelper});
  if(name==='backups')return send(200,await privileged({op:'backups'}));
  if(name==='disks')return send(200,await privileged({op:'disks',action:'list'}));
  if(name==='remote')return send(200,await privileged({op:'remote',action:'status'}));
  if(name==='jobs')return send(200,await privileged({op:'jobs'}));
  fail('Rota inexistente',404);
 }
 if(req.method!=='POST')fail('Método não permitido',405);
 const b=await body(req);
 if(name==='setup'){
  if(typeof b.name!=='string'||!b.name.trim()||b.name.length>60||!(b.latitude===null||typeof b.latitude==='number'&&Number.isFinite(b.latitude)&&Math.abs(b.latitude)<=90)||!(b.longitude===null||typeof b.longitude==='number'&&Number.isFinite(b.longitude)&&Math.abs(b.longitude)<=180))fail('Nome ou localização inválidos');
  await saveJSON('setup.json',{completed:!!b.completed,name:b.name.trim(),latitude:b.latitude,longitude:b.longitude});await audit(req.user,'configuração.guardada');return send(200,{ok:true});
 }
 if(operation)fail('Outra operação administrativa está a ser preparada',409);operation=true;
 try{
  if(name==='updates'&&b.action==='check'){
   if(!github(b.feed))fail('Indique o URL HTTPS de release.json no GitHub (raw.githubusercontent.com)');
   const r=await fetch(b.feed,{redirect:'error',signal:AbortSignal.timeout(15000),headers:{Accept:'application/json'}});if(!r.ok)fail('Não foi possível obter o manifesto do GitHub',502);const text=await r.text();if(text.length>16000)fail('Manifesto demasiado grande');const release=JSON.parse(text),u=new URL(release.packageUrl),feed=new URL(b.feed),repo=feed.pathname.split('/').slice(1,3).join('/');
   if(!/^\d+\.\d+\.\d+$/.test(release.version)||!/^([a-f0-9]{64})$/.test(release.sha256)||u.protocol!=='https:'||!['github.com','raw.githubusercontent.com'].includes(u.hostname)||u.pathname.split('/').slice(1,3).join('/')!==repo||!u.pathname.endsWith('.zip')||u.username||u.password)fail('Manifesto inválido: versão, SHA256 e pacote ZIP do mesmo repositório são obrigatórios');
   const source={feed:b.feed,release:{version:release.version,packageUrl:release.packageUrl,sha256:release.sha256},checked:new Date().toISOString()};await saveJSON('update-source.json',source);await audit(req.user,'atualização.consultada',release.version);return send(200,{...source,current:version});
  }
  reauthenticate(req,b.password);
  let request;
  if(name==='backups'){
   if(b.action==='create')request={op:'job',action:'create'};
   else if(b.action==='restore'){if(b.confirm!=='RESTAURAR')fail('Escreva RESTAURAR para confirmar');request={op:'job',action:'restore',id:b.id,confirm:b.confirm}}
   else if(b.action==='destination')request={op:'backups',action:'destination',uuid:b.uuid||null};
  }
  if(name==='updates'){
   if(b.action==='install'){if(b.confirm!=='ATUALIZAR')fail('Escreva ATUALIZAR para confirmar');const s=await readJSON('update-source.json',{});if(!s.release)fail('Consulte primeiro uma versão no GitHub');request={op:'job',action:'update',release:s.release}}
   if(b.action==='rollback'){if(b.confirm!=='REVERTER')fail('Escreva REVERTER para confirmar');request={op:'job',action:'rollback'}}
  }
  if(name==='disks'&&['mount','unmount'].includes(b.action))request={op:'disks',action:b.action,uuid:b.uuid};
  if(name==='remote'&&['connect','disconnect','serve','unserve'].includes(b.action))request={op:'remote',action:b.action};
  if(!request)fail('Operação inválida');
  const result=await privileged(request);await audit(req.user,name+'.'+b.action,b.id||b.uuid||'');return send(200,result);
 }finally{operation=false}
}catch(e){send(e.status||400,{error:e.message||'Não foi possível concluir a operação'})}}
