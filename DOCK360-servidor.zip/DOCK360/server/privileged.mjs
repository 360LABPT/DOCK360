import {spawn} from 'node:child_process';
export const hasHelper=process.env.DOCK_PRIVILEGED_HELPER==='1';
export const helperPath='/usr/local/libexec/36odock-admin';
export async function privileged(request){
 if(!hasHelper)throw Object.assign(Error('Esta função requer o instalador Raspberry Pi atualizado.'),{status:503});
 return new Promise((resolve,reject)=>{const p=spawn('sudo',['-n',helperPath],{stdio:['pipe','pipe','pipe']});let out='',err='';const timer=setTimeout(()=>{p.kill();reject(Object.assign(Error('O assistente excedeu o tempo limite'),{status:504}))},45000);p.stdout.on('data',d=>{out+=d;if(out.length>32e6)p.kill()});p.stderr.on('data',d=>{err+=d;if(err.length>4096)err=err.slice(-4096)});p.on('error',e=>{clearTimeout(timer);reject(Object.assign(Error('Assistente do sistema indisponível'),{status:503}))});p.on('exit',()=>{clearTimeout(timer);try{let d=JSON.parse(out);if(!d.ok)throw Object.assign(Error(d.error),{status:d.status||500});resolve(d.result)}catch(e){reject(e.status?e:Object.assign(Error('Não foi possível executar a operação do sistema'),{status:503}))}});p.stdin.on('error',()=>{});p.stdin.end(JSON.stringify(request));});
}
