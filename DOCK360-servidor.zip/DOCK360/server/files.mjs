import {mkdir,readdir,lstat,realpath,writeFile,readFile,rename,unlink,rmdir} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {hasHelper,privileged} from './privileged.mjs';
import {teamAccess,teamRoot} from './teams.mjs';
import {audit} from './store.mjs';
const homes=path.resolve(process.env.DOCK_HOMES_ROOT||new URL('../data/homes',import.meta.url).pathname);
export const MAX=20*1024*1024;
const fail=(s,status=400)=>{throw Object.assign(Error(s),{status})};
async function localRoot(user,scope){if(scope==='system'){if(user.role!=='admin')fail('Só o administrador pode aceder ao sistema',403);return path.resolve(process.env.DOCK_SYSTEM_ROOT||'/')}if(scope!=='private')fail('Âmbito inválido');const dir=path.join(homes,createHash('sha256').update(user.username).digest('hex').slice(0,32));await mkdir(dir,{recursive:true,mode:0o700});return await realpath(dir)}
async function safe(base,rel=''){if(typeof rel!=='string'||rel.includes('\0')||rel.includes('\\')||path.isAbsolute(rel)||rel.split('/').some(p=>p==='..'||p==='.'))fail('Caminho inválido');let target=base;for(const part of rel.split('/').filter(Boolean)){target=path.join(target,part);try{if((await lstat(target)).isSymbolicLink())fail('Ligações simbólicas não permitidas',403)}catch(e){if(e.code!=='ENOENT')throw e}}return target}
export async function filesRoute(req,res,url){const send=(s,d)=>{res.writeHead(s,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d))};try{
 let b={scope:url.searchParams.get('scope')||'private',path:url.searchParams.get('path')||'',op:url.pathname.endsWith('/download')?'download':'list'};
 if(req.method==='POST'){if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)fail('Origem inválida',403);let chunks=[],n=0;for await(const c of req){n+=c.length;if(n>MAX*1.4+8192)fail('Limite: 20 MB',413);chunks.push(c)}b=JSON.parse(Buffer.concat(chunks).toString());b.scope=b.scope||'private'}else if(req.method!=='GET')return send(405,{error:'Método não permitido'});
 if(b.scope==='system'&&req.user.role!=='admin')fail('Só o administrador pode aceder ao sistema',403);
 if(b.scope==='team')await teamAccess(req.user,b.team||url.searchParams.get('team'),!['list','download'].includes(b.op));b.team=b.team||url.searchParams.get('team');
 if(!['private','system','team'].includes(b.scope))fail('Âmbito inválido');
 let result;
 if(hasHelper){result=await privileged({op:'files',request:{...b,username:req.user.username}})}else{
  const base=b.scope==='team'?await teamRoot(req.user,b.team,!['list','download'].includes(b.op)):await localRoot(req.user,b.scope),p=await safe(base,b.path);if(p===base&&!['list'].includes(b.op))fail('Não é permitido alterar a raiz');
  if(b.op==='list'){let rows=[];for(const name of await readdir(p)){const st=await lstat(path.join(p,name));if(st.isSymbolicLink()||(!st.isDirectory()&&!st.isFile()))continue;rows.push({name,kind:st.isDirectory()?'folder':'file',size:st.size,modified:st.mtime.toISOString()})}result={entries:rows}}
  else if(b.op==='download'){const st=await lstat(p);if(!st.isFile())fail('Selecione um ficheiro regular');if(st.size>MAX)fail('Limite: 20 MB',413);result={content:(await readFile(p)).toString('base64')}}
  else if(b.op==='mkdir')await mkdir(p,{mode:0o700});
  else if(['upload','write'].includes(b.op)){if(typeof b.content!=='string')fail('Conteúdo inválido');const data=Buffer.from(b.content,'base64');if(data.length>MAX)fail('Limite: 20 MB',413);if(b.op==='write'){const st=await lstat(p);if(!st.isFile()||st.size>MAX)fail('Ficheiro não editável');const hash=createHash('sha256').update(await readFile(p)).digest('hex');if(hash!==b.expectedHash)fail('O ficheiro foi alterado. Reabra-o.',409)}await writeFile(p,data,{flag:b.op==='upload'?'wx':'w',mode:0o600})}
  else if(b.op==='rename'){if(typeof b.name!=='string'||!b.name.trim()||/[\\/\0]/.test(b.name)||['.','..'].includes(b.name))fail('Nome inválido');const dest=await safe(base,path.posix.join(path.posix.dirname(b.path),b.name));try{await lstat(dest);fail('O nome já existe',409)}catch(e){if(e.code!=='ENOENT')throw e}await rename(p,dest)}
  else if(b.op==='delete'){const st=await lstat(p);if(st.isDirectory())await rmdir(p);else if(st.isFile())await unlink(p);else fail('Selecione um ficheiro regular')}
  else fail('Operação inválida');
 }
 if(b.op==='download'){res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(path.basename(b.path)),'Cache-Control':'no-store'});return res.end(Buffer.from(result.content,'base64'))}
 if(!['list','download'].includes(b.op))await audit(req.user,'ficheiro.'+b.op,b.scope+':'+(b.team||'')+':'+b.path);
 send(200,result||{ok:true});
}catch(e){const status=e.status||({ENOENT:404,EEXIST:409,ENOTEMPTY:409,EACCES:403,ENOTDIR:400}[e.code])||400;send(status,{error:e.status?e.message:({ENOENT:'Ficheiro ou pasta inexistente',EEXIST:'O nome já existe',ENOTEMPTY:'A pasta deve estar vazia antes de eliminar',EACCES:'Sem permissão',ENOTDIR:'Não é uma pasta'}[e.code]||'Não foi possível concluir a operação')})}}
