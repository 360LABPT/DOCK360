import {createHmac,timingSafeEqual,randomBytes,createHash} from 'node:crypto';
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function encode32(buffer){let bits=0,value=0,out='';for(const byte of buffer){value=(value<<8)|byte;bits+=8;while(bits>=5){out+=alphabet[(value>>>(bits-5))&31];bits-=5}}if(bits)out+=alphabet[(value<<(5-bits))&31];return out}
function decode32(s){let bits=0,value=0,out=[];for(const c of s){const i=alphabet.indexOf(c);if(i<0)throw Error('Segredo inválido');value=(value<<5)|i;bits+=5;if(bits>=8){out.push((value>>>(bits-8))&255);bits-=8}}return Buffer.from(out)}
export const secret=()=>encode32(randomBytes(20));
export function totp(key,step,digits=6){const counter=Buffer.alloc(8);counter.writeBigUInt64BE(BigInt(step));const h=createHmac('sha1',decode32(key)).update(counter).digest(),o=h[19]&15;return String((h.readUInt32BE(o)&0x7fffffff)%10**digits).padStart(digits,'0')}
export function verify(key,code,last=-1,now=Date.now()){if(typeof code!=='string'||!/^\d{6}$/.test(code))return null;const step=Math.floor(now/30000);for(let i=-1;i<=1;i++){const n=step+i;if(n>last&&timingSafeEqual(Buffer.from(totp(key,n)),Buffer.from(code)))return n}return null}
export const recoveryHash=code=>createHash('sha256').update(String(code).toUpperCase().replace(/[-\s]/g,'')).digest('hex');
