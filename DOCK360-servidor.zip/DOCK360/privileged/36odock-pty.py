#!/usr/bin/python3
import os,pty,sys,select,json,base64,fcntl,termios,struct,signal,time
pid,master=pty.fork()
if pid==0:
 os.chdir('/root' if os.geteuid()==0 else os.path.expanduser('~'))
 os.execve('/bin/bash',['bash','--noprofile','--norc'],{'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root' if os.geteuid()==0 else os.path.expanduser('~'),'TERM':'xterm-256color','LANG':'C.UTF-8','PS1':'DOCK360:\\w\\$ '})
buffer=b'';last=time.monotonic()
try:
 while time.monotonic()-last<900:
  ready,_,_=select.select([master,sys.stdin.fileno()],[],[],1)
  if master in ready:
   try:out=os.read(master,8192)
   except OSError:break
   if not out:break
   print(json.dumps({'data':base64.b64encode(out).decode()}),flush=True)
  if sys.stdin.fileno() in ready:
   block=os.read(sys.stdin.fileno(),16384)
   if not block:break
   buffer+=block
   if len(buffer)>65536:break
   while b'\n' in buffer:
    line,buffer=buffer.split(b'\n',1);b=json.loads(line);last=time.monotonic()
    if b.get('op')=='write':os.write(master,base64.b64decode(b['data'],validate=True))
    elif b.get('op')=='resize':
     cols=max(20,min(400,int(b['cols'])));rows=max(5,min(150,int(b['rows'])))
     fcntl.ioctl(master,termios.TIOCSWINSZ,struct.pack('HHHH',rows,cols,0,0))
    elif b.get('op')=='close':raise EOFError()
except (EOFError,ValueError,KeyError,json.JSONDecodeError):pass
finally:
 try:os.killpg(pid,signal.SIGHUP)
 except ProcessLookupError:pass
 os.close(master)
 print(json.dumps({'exit':True}),flush=True)
