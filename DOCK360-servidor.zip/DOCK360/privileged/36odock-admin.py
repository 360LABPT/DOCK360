#!/usr/bin/python3
"""Root-owned broker: fixed JSON operations. Installed sudoers allows only this entry point."""
import os,sys,json,re,hashlib,pwd,subprocess,stat,base64,ctypes,errno,secrets,importlib.util,types
from pathlib import Path
CONFIG=Path('/etc/36odock-helper.json')
DATA=Path('/var/lib/36odock/config');HOMES=Path('/var/lib/36odock/homes');SAMBA_CONF=Path('/etc/samba/36odock.conf')
MAX=20*1024*1024
class Fault(Exception):
 def __init__(self,message,status=400):self.message=message;self.status=status
def run(args,stdin=None):
 p=subprocess.run(args,input=stdin,text=True,capture_output=True,timeout=30)
 if p.returncode:raise Fault('A operação do sistema falhou. Consulte os registos locais.',503)
 return p.stdout
def name_for(username):
 if not isinstance(username,str) or not re.fullmatch(r'[a-zA-Z0-9_.-]{3,40}',username):raise Fault('Utilizador inválido')
 return 'd36_'+re.sub('[^a-z0-9]','_',username.lower())[:12]+'_'+hashlib.sha256(username.encode()).hexdigest()[:8]
def home_for(username):return HOMES/hashlib.sha256(username.encode()).hexdigest()[:32]
def account(username):
 name=name_for(username);home=home_for(username)
 try:u=pwd.getpwnam(name)
 except KeyError:
  run(['/usr/sbin/useradd','--system','--user-group','--home-dir',str(home),'--shell','/usr/sbin/nologin',name]);u=pwd.getpwnam(name)
 if u.pw_dir!=str(home):raise Fault('A conta do sistema tem uma pasta incompatível',409)
 HOMES.mkdir(mode=0o711,parents=True,exist_ok=True)
 if home.is_symlink():raise Fault('Pasta privada inválida',403)
 home.mkdir(mode=0o700,exist_ok=True);os.chmod(home,0o700);os.chown(home,u.pw_uid,u.pw_gid)
 return u,home

def services():
 spec=importlib.util.spec_from_file_location('dock360_services',Path(__file__).with_name('36odock-services.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.configure(DATA,HOMES);return module

def broker_context():return types.SimpleNamespace(DATA=DATA,HOMES=HOMES,account=account,name_for=name_for,samba=samba)

def root_and_owner(b):
 if b.get('scope')=='team':return services().team_owner(b,broker_context())
 if b.get('scope','private')=='system':return Path('/'),None
 if b.get('scope','private')!='private':raise Fault('Âmbito inválido')
 u,home=account(b['username']);return home,u

def validate_rel(rel):
 if not isinstance(rel,str) or '\0' in rel or '\\' in rel or rel.startswith('/') or any(s in ['.','..'] for s in rel.split('/')):raise Fault('Caminho inválido')
 return [p for p in rel.split('/') if p]
def opened_parent(base,rel,system=False):
 parts=validate_rel(rel)
 if system:
  target=(base/rel).resolve(strict=False)
  if target.parts[1:2] in [('proc',),('sys',),('dev',)]:raise Fault('Este sistema virtual não é gerido como ficheiros regulares',403)
  parts=list(target.parts[1:]);base=Path('/')
 fd=os.open(base,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in parts[:-1]:
   nxt=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=nxt
  return fd,parts[-1] if parts else '.',parts
 except:os.close(fd);raise

def files(b):
 base,owner=root_and_owner(b);system=owner is None;fd,name,parts=opened_parent(base,b.get('path',''),system)
 try:
  op=b.get('op','list')
  if op=='list':
   d=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
   try:
    rows=[]
    for n in os.listdir(d):
     try:
      st=os.stat(n,dir_fd=d,follow_symlinks=False)
      kind='folder' if stat.S_ISDIR(st.st_mode) else 'file' if stat.S_ISREG(st.st_mode) else 'link' if stat.S_ISLNK(st.st_mode) else 'special'
      if kind in ['special','link']:continue
      rows.append({'name':n,'kind':kind,'size':st.st_size,'modified':__import__('datetime').datetime.fromtimestamp(st.st_mtime,__import__('datetime').timezone.utc).isoformat()})
     except (FileNotFoundError,PermissionError):pass
    return {'entries':rows}
   finally:os.close(d)
  if not parts:raise Fault('Não é permitido alterar a raiz')
  if op=='download':
   f=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
   try:
    st=os.fstat(f)
    if not stat.S_ISREG(st.st_mode):raise Fault('Selecione um ficheiro regular')
    if st.st_size>MAX:raise Fault('Limite: 20 MB',413)
    with os.fdopen(os.dup(f),'rb') as source:data=source.read(MAX+1)
    if len(data)>MAX:raise Fault('Limite: 20 MB',413)
    return {'content':base64.b64encode(data).decode()}
   finally:os.close(f)
  if op=='mkdir':
   os.mkdir(name,0o755 if system else 0o2770 if getattr(owner,'team',False) else 0o700,dir_fd=fd)
   if owner:
    os.chown(name,owner.pw_uid,owner.pw_gid,dir_fd=fd,follow_symlinks=False)
    if getattr(owner,'team',False):os.chmod(name,0o2770,dir_fd=fd,follow_symlinks=False)
  elif op in ['upload','write']:
   try:data=base64.b64decode(b.get('content',''),validate=True)
   except:raise Fault('Conteúdo inválido')
   if len(data)>MAX:raise Fault('Limite: 20 MB',413)
   if op=='upload':
    f=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644 if system else 0o660 if getattr(owner,'team',False) else 0o600,dir_fd=fd)
    try:
     if owner:os.fchown(f,owner.pw_uid,owner.pw_gid)
     with os.fdopen(os.dup(f),'wb') as out:out.write(data)
    finally:os.close(f)
   else:
    # Edit only existing regular files, with an optimistic content hash.
    f=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
    try:
     st=os.fstat(f)
     if not stat.S_ISREG(st.st_mode) or st.st_size>MAX:raise Fault('Ficheiro não editável')
     old=os.read(f,MAX+1)
     if hashlib.sha256(old).hexdigest()!=b.get('expectedHash'):raise Fault('O ficheiro foi alterado. Reabra-o antes de guardar.',409)
    finally:os.close(f)
    temp='.36odock-'+secrets.token_hex(12)
    try:
     f=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,stat.S_IMODE(st.st_mode),dir_fd=fd)
     try:
      os.fchown(f,st.st_uid,st.st_gid)
      with os.fdopen(os.dup(f),'wb') as out:out.write(data);out.flush();os.fsync(out.fileno())
     finally:os.close(f)
     os.rename(temp,name,src_dir_fd=fd,dst_dir_fd=fd)
    finally:
     try:os.unlink(temp,dir_fd=fd)
     except FileNotFoundError:pass
  elif op=='rename':
   dest=b.get('name','')
   if not isinstance(dest,str) or dest in ['.','..'] or not dest.strip() or any(c in dest for c in '/\\\0'):raise Fault('Nome inválido')
   libc=ctypes.CDLL(None,use_errno=True)
   if libc.renameat2(fd,os.fsencode(name),fd,os.fsencode(dest),1):raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
  elif op=='delete':
   st=os.stat(name,dir_fd=fd,follow_symlinks=False)
   if stat.S_ISLNK(st.st_mode):raise Fault('Ligações simbólicas não permitidas',403)
   if stat.S_ISDIR(st.st_mode):os.rmdir(name,dir_fd=fd)
   elif stat.S_ISREG(st.st_mode):os.unlink(name,dir_fd=fd)
   else:raise Fault('Selecione um ficheiro regular')
  else:raise Fault('Operação inválida')
  return {'ok':True}
 finally:os.close(fd)

def samba_config():
 rows=json.loads((DATA/'users.json').read_text());lines=['# DOCK360 private shares — managed by the installer','']
 for row in rows:
  u,home=account(row['username']);name=u.pw_name
  lines += ['['+name+']','    path = '+str(home),'    valid users = '+name,'    browseable = no','    read only = no','    guest ok = no','    create mask = 0600','    directory mask = 0700','    follow symlinks = no','    wide links = no','']
 lines+=services().team_samba_lines(broker_context())
 return '\n'.join(lines)

def samba(b):
 op=b.get('action','status');u,home=account(b['username']);name=u.pw_name
 if op=='password':
  p=b.get('password','')
  if not isinstance(p,str) or not 12<=len(p)<=256 or '\n' in p or '\r' in p or '\0' in p:raise Fault('Utilize 12 a 256 caracteres, sem quebras de linha')
  run(['/usr/bin/smbpasswd','-c','/etc/samba/smb.conf','-a','-s',name],p+'\n'+p+'\n')
  run(['/usr/bin/smbpasswd','-c','/etc/samba/smb.conf','-e',name])
 elif op=='disable':
  subprocess.run(['/usr/bin/smbpasswd','-c','/etc/samba/smb.conf','-d',name],capture_output=True,timeout=15)
 elif op=='sync':
  content=samba_config();temp=SAMBA_CONF.with_suffix('.new');temp.write_text(content);os.chmod(temp,0o600)
  try:run(['/usr/bin/testparm','-s',str(temp)])
  except:temp.unlink(missing_ok=True);raise
  os.replace(temp,SAMBA_CONF)
  run(['/bin/systemctl','reload-or-restart','smbd.service'])
 elif op!='status':raise Fault('Operação Samba inválida')
 active=subprocess.run(['/bin/systemctl','is-active','--quiet','smbd.service'],timeout=5).returncode==0
 return {'active':active,'username':name,'share':name,'private':True}

def dispatch(b):
 op=b.get('op')
 if op=='files':return files(b['request'])
 if op=='provision':u,home=account(b['username']);return {'username':u.pw_name}
 if op=='samba':return samba(b)
 if op=='reboot':
  # This code executes only when called by an authenticated admin API action.
  run(['/bin/systemd-run','--on-active=3s','--unit=36odock-reboot','/bin/systemctl','reboot']);return {'scheduled':True}
 if op in ['disks','teams','remote','jobs','backups','job']:return services().dispatch(b,broker_context())
 if op=='status':return {'privileged':True,'systemFiles':True,'terminal':True,'samba':SAMBA_CONF.exists()}
 raise Fault('Operação não permitida')

def main():
 global DATA,HOMES
 if os.geteuid()!=0:raise Fault('O assistente necessita de permissões do sistema',503)
 if CONFIG.exists():
  config=json.loads(CONFIG.read_text());DATA=Path(config['data']);HOMES=Path(config['homes'])
 if len(sys.argv)==3 and sys.argv[1]=='--job':
  services().job_run(sys.argv[2]);return
 if sys.argv[1:]==['terminal']:
  os.execv('/usr/bin/python3',['python3','-I','/usr/local/libexec/36odock-pty.py']);return
 if sys.argv[1:]:raise Fault('Argumentos não permitidos')
 data=sys.stdin.buffer.read(MAX*2+16384)
 if len(data)>MAX*1.4+8192:raise Fault('Pedido demasiado grande',413)
 result=dispatch(json.loads(data));print(json.dumps({'ok':True,'result':result}))
if __name__=='__main__':
 try:main()
 except Fault as e:print(json.dumps({'ok':False,'error':e.message,'status':e.status}))
 except OSError as e:print(json.dumps({'ok':False,'error':{errno.ENOENT:'Ficheiro ou pasta inexistente',errno.EEXIST:'O nome já existe',errno.ENOTEMPTY:'A pasta deve estar vazia',errno.EACCES:'Sem permissão',errno.ELOOP:'Ligações simbólicas não permitidas'}.get(e.errno,'Operação de ficheiros falhou'),'status':{errno.ENOENT:404,errno.EEXIST:409,errno.ENOTEMPTY:409,errno.EACCES:403,errno.ELOOP:403}.get(e.errno,400)}))
 except Exception:print(json.dumps({'ok':False,'error':'A operação do sistema falhou','status':500}))
