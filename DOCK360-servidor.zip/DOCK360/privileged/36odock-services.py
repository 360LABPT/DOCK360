"""DOCK360 operations. Invoked only through the installed root broker."""
import os,json,re,time,uuid,hashlib,shutil,subprocess,tarfile,zipfile,stat,fcntl,urllib.request,urllib.parse,io
from pathlib import Path
LIBEXEC=Path('/usr/local/libexec')
ROOT=Path('/var/lib/36odock');INSTALL=Path('/opt/36odock');MOUNTS=Path('/mnt/dock360')
DATA=ROOT/'config';JOBS=ROOT/'operations';BACKUPS=ROOT/'backups';TEAMS=ROOT/'teams'
class OperationError(Exception):pass
def run(args,timeout=60,check=True):
 p=subprocess.run([str(a) for a in args],capture_output=True,text=True,timeout=timeout)
 if check and p.returncode:raise OperationError('Falhou: '+str(args[0])+' (consulte os registos do sistema).')
 return p.stdout

def write_json(file,obj):
 file.parent.mkdir(parents=True,exist_ok=True,mode=0o700);tmp=file.with_name(file.name+'.tmp-'+uuid.uuid4().hex);tmp.write_text(json.dumps(obj));os.chmod(tmp,0o600);os.replace(tmp,file)
def load(file,default=None):
 try:return json.loads(file.read_text())
 except FileNotFoundError:return default

def configure(data,homes):
 global DATA,ROOT,JOBS,BACKUPS,TEAMS
 DATA=Path(data);ROOT=DATA.parent;JOBS=ROOT/'operations';BACKUPS=ROOT/'backups';TEAMS=ROOT/'teams'

def disk_rows():
 raw=json.loads(run(['/usr/bin/lsblk','--json','--bytes','--paths','--output','NAME,TYPE,SIZE,FSTYPE,UUID,LABEL,MOUNTPOINTS,TRAN,RM,RO,PKNAME']))
 out=[]
 def visit(row,parent=None,blocked=False):
  mounts=[m for m in row.get('mountpoints',[]) if m];system=blocked or any(m in ['/','/boot','/boot/firmware','/var','/var/lib','/var/lib/36odock','/opt','/opt/36odock','[SWAP]'] for m in mounts)
  children=row.get('children',[])
  def has_system(r):return any(m in ['/','/boot','/boot/firmware','/var','/var/lib','/var/lib/36odock','/opt','/opt/36odock','[SWAP]'] for m in r.get('mountpoints',[]) if m) or any(has_system(c) for c in r.get('children',[]))
  system=system or has_system(row)
  transport=row.get('tran') or (parent or {}).get('transport');external=transport=='usb'
  item={k:row.get(k) for k in ['name','type','size','fstype','uuid','label','ro']};item.update(mounts=mounts,external=external,transport=transport,system=system)
  eligible=transport in ['usb','nvme','sata'] and not system and not row.get('ro') and row.get('type') in ['part','disk'] and not children and row.get('fstype') in ['ext4','exfat','vfat','ntfs','ntfs3','xfs','btrfs'] and isinstance(row.get('uuid'),str) and bool(re.fullmatch('[A-Za-z0-9-]{4,80}',row['uuid']))
  item['manageable']=bool(eligible);out.append(item)
  for c in children:visit(c,item,system)
 for row in raw['blockdevices']:visit(row)
 return out

def disk(b):
 if b.get('action','list')=='list':return {'disks':disk_rows()}
 rows=disk_rows();d=next((d for d in rows if d['uuid']==b.get('uuid') and d['manageable']),None)
 if not d:raise OperationError('Selecione uma partição de dados USB/SSD; os discos do sistema estão protegidos.')
 MOUNTS.mkdir(parents=True,exist_ok=True);mount=MOUNTS/d['uuid']
 if b['action']=='mount':
  if d['mounts']:raise OperationError('O disco já está montado.')
  if mount.is_symlink():raise OperationError('Ponto de montagem inválido.')
  mount.mkdir(mode=0o750,exist_ok=True)
  run(['/bin/mount','-o','nosuid,nodev,noexec','--','/dev/disk/by-uuid/'+d['uuid'],mount])
 elif b['action']=='unmount':
  if d['mounts']!=[str(mount)]:raise OperationError('Só pode desmontar discos montados pelo DOCK360.')
  run(['/bin/umount','--',mount])
 else:raise OperationError('Operação de disco inválida.')
 return {'disks':disk_rows()}

def backup_dir():
 conf=load(ROOT/'backup-destination.json',{})
 if not conf.get('uuid'):BACKUPS.mkdir(mode=0o700,parents=True,exist_ok=True);return BACKUPS
 disk=next((d for d in disk_rows() if d['uuid']==conf['uuid'] and d['manageable']),None)
 target=MOUNTS/conf['uuid']
 if not disk or disk['mounts']!=[str(target)] or not os.path.ismount(target):raise OperationError('O disco de cópias de segurança não está montado. Nenhuma cópia foi gravada no cartão SD.')
 dest=target/'DOCK360-backups'
 if dest.is_symlink():raise OperationError('Destino inválido.')
 dest.mkdir(mode=0o700,exist_ok=True);return dest

def backup_list():
 dest=backup_dir();rows=[]
 for file in dest.glob('dock360-*.tar.gz'):
  if file.is_symlink() or not file.is_file():continue
  info=load(file.with_suffix(file.suffix+'.json'),{});rows.append({'id':file.name,'size':file.stat().st_size,'created':info.get('created'),'sha256':info.get('sha256'),'volumes':info.get('volumes',[])})
 return {'backups':sorted(rows,key=lambda r:r['id'],reverse=True),'destination':str(dest),'external':dest!=BACKUPS}

def managed_containers():
 try:ids=run(['/usr/bin/docker','ps','-aq','--filter','label=36odock.managed=true']).split()
 except FileNotFoundError:return []
 if not ids:return []
 return json.loads(run(['/usr/bin/docker','inspect',*ids]))

def managed_volumes(containers):
 names=set()
 for c in containers:
  for m in c.get('Mounts',[]):
   if m['Type']=='volume' and re.fullmatch(r'36odock-[a-z0-9-]+',m.get('Name','')):names.add(m['Name'])
 if not names:return []
 return json.loads(run(['/usr/bin/docker','volume','inspect',*sorted(names)]))

def restart_containers(names):
 if names:run(['/usr/bin/docker','start',*names],timeout=180)

def backup_create(job):
 dest=backup_dir();containers=managed_containers();volumes=managed_volumes(containers);running=[c['Id'] for c in containers if c['State']['Running']]
 samba=bool(run(['/bin/systemctl','is-active','smbd.service'],check=False).strip()=='active')
 filename='dock360-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+job[:8]+'.tar.gz';target=dest/filename;temp=dest/(filename+'.part')
 manifest={'format':1,'created':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'volumes':[v['Name'] for v in volumes],'containers':[{'name':c['Name'].lstrip('/'),'image':c['Config']['Image']} for c in containers],'includes':['config','homes','teams','managed-volumes'],'note':'Reinstale as mesmas aplicações para recriar contentores; configurações de aplicações são preservadas nos volumes.'}
 try:
  if samba:run(['/bin/systemctl','stop','smbd.service'])
  if running:run(['/usr/bin/docker','stop','--time','45',*running],timeout=180)
  with tarfile.open(temp,'w:gz',dereference=False) as archive:
   data=json.dumps(manifest).encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);info.mode=0o600;archive.addfile(info,io.BytesIO(data))
   for name in ['config','homes','teams']:
    source=ROOT/name
    if source.exists():archive.add(source,arcname=name,recursive=True)
   for volume in volumes:
    source=Path(volume['Mountpoint'])
    if not source.is_dir() or source.is_symlink():raise OperationError('Volume Docker inválido.')
    archive.add(source,arcname='volumes/'+volume['Name'],recursive=True)
  os.chmod(temp,0o600);os.replace(temp,target)
  h=hash_file(target);write_json(target.with_suffix(target.suffix+'.json'),{**manifest,'sha256':h,'size':target.stat().st_size});return {'id':filename,'sha256':h}
 finally:
  temp.unlink(missing_ok=True)
  try:restart_containers(running)
  finally:
   if samba:run(['/bin/systemctl','start','smbd.service'])

def hash_file(file):
 h=hashlib.sha256()
 with file.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def validate_backup(archive):
 members=archive.getmembers();names=set();total=0
 for m in members:
  p=Path(m.name)
  if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0] not in ['manifest.json','config','homes','teams','volumes'] or m.name in names:raise OperationError('Cópia com caminhos inválidos.')
  names.add(m.name);total+=m.size
  if not(m.isfile() or m.isdir() or m.issym() or m.islnk()):raise OperationError('Cópia com ficheiros especiais.')
  if m.issym() or m.islnk():
   # Never extract outside the staging tree, even through a link chain.
   link=Path(m.linkname)
   if link.is_absolute() or '..' in link.parts:raise OperationError('Cópia com ligações externas. Corrija a origem antes de criar nova cópia.')
  if len(members)>1000000 or total>shutil.disk_usage(ROOT).free:raise OperationError('Espaço insuficiente para preparar o restauro.')
 manifest=json.load(archive.extractfile('manifest.json'))
 if manifest.get('format')!=1:raise OperationError('Formato de cópia incompatível.')
 if any(not re.fullmatch(r'36odock-[a-z0-9-]+',v) for v in manifest.get('volumes',[])):raise OperationError('Volume inválido na cópia.')
 return manifest

def load_broker():
 from importlib.machinery import SourceFileLoader
 from importlib.util import spec_from_loader,module_from_spec
 loader=SourceFileLoader('dock_broker','/usr/local/libexec/36odock-admin');spec=spec_from_loader(loader.name,loader);broker=module_from_spec(spec);loader.exec_module(broker);return broker

def backup_restore(b,job):
 if b.get('confirm')!='RESTAURAR':raise OperationError('Confirme escrevendo RESTAURAR.')
 name=b.get('id','')
 if not re.fullmatch(r'dock360-[A-Za-z0-9-]+\.tar\.gz',name):raise OperationError('Cópia inválida.')
 file=backup_dir()/name;info=load(file.with_suffix(file.suffix+'.json'),{})
 if file.is_symlink() or not info.get('sha256') or hash_file(file)!=info['sha256']:raise OperationError('A verificação SHA256 da cópia falhou.')
 stage=ROOT/('restore-'+job);rollback=ROOT/('before-restore-'+job);stage.mkdir(mode=0o700);rollback.mkdir(mode=0o700)
 containers=managed_containers();running=[c['Id'] for c in containers if c['State']['Running']];samba=run(['/bin/systemctl','is-active','smbd.service'],check=False).strip()=='active';swapped=[];stopped=False
 try:
  with tarfile.open(file,'r:gz') as archive:
   manifest=validate_backup(archive);archive.extractall(stage,filter=lambda member,dest: tarfile.data_filter(member,dest).replace(uid=member.uid,gid=member.gid))
  users=load(stage/'config/users.json',[])
  if not users or not any(u.get('role')=='admin' for u in users):raise OperationError('A cópia não contém uma conta de administrador.')
  installed={c['Name'].lstrip('/'):c['Config']['Image'] for c in containers}
  if any(installed.get(c['name'])!=c['image'] for c in manifest.get('containers',[])):raise OperationError('Instale primeiro as mesmas aplicações e versões que constam da cópia.')
  existing={v['Name']:Path(v['Mountpoint']) for v in managed_volumes(containers)}
  if any(v not in existing for v in manifest['volumes']):raise OperationError('Instale primeiro as aplicações da cópia: '+', '.join(v for v in manifest['volumes'] if v not in existing))
  if running:run(['/usr/bin/docker','stop','--time','45',*running],timeout=180)
  if samba:run(['/bin/systemctl','stop','smbd.service'])
  run(['/bin/systemctl','stop','36odock.service']);stopped=True
  # Data and named volumes are replaced by atomic renames, with rollback retained.
  pairs=[(ROOT/n,stage/n) for n in ['config','homes','teams'] if (stage/n).exists()]+[(existing[v],stage/'volumes'/v) for v in manifest['volumes']]
  for i,(target,source) in enumerate(pairs):
   if source.stat().st_dev!=target.parent.stat().st_dev:
    adjacent=target.with_name(target.name+'.staged-'+job);shutil.copytree(source,adjacent,symlinks=True,copy_function=shutil.copy2);source=adjacent
   saved=target.with_name(target.name+'.before-'+job)
   if saved.exists():raise OperationError('Pasta de recuperação já existe.')
   if target.exists():os.replace(target,saved)
   try:os.replace(source,target)
   except:
    if saved.exists():os.replace(saved,target)
    raise
   swapped.append((target,saved))
  # Account IDs may differ on another Raspberry. Reapply the native ownership.
  broker=load_broker();broker.DATA=DATA;broker.HOMES=ROOT/'homes'
  for u in users:
   account,home=broker.account(u['username'])
   for root,dirs,files in os.walk(home,followlinks=False):
    os.chown(root,account.pw_uid,account.pw_gid);os.chmod(root,0o700)
    for n in files:
     p=Path(root)/n
     if not p.is_symlink():os.chown(p,account.pw_uid,account.pw_gid);os.chmod(p,0o600)
  sync_teams(broker);broker.samba({'action':'sync','username':users[0]['username']})
  run(['/bin/chown','-R','dock36:dock36',DATA]);run(['/bin/systemctl','start','36odock.service']);health()
  return {'restored':name,'previousData':[str(saved) for _,saved in swapped],'note':'Entre com as credenciais existentes na cópia. A palavra-passe Samba deve ser redefinida em cada conta.'}
 except:
  if stopped:
   run(['/bin/systemctl','stop','36odock.service'],check=False)
   run(['/bin/systemctl','stop','smbd.service'],check=False)
  for target,saved in reversed(swapped):
   failed=target.with_name(target.name+'.failed-'+job)
   if target.exists():os.replace(target,failed)
   if saved.exists():os.replace(saved,target)
  raise
 finally:
  try:
   if stopped:run(['/bin/systemctl','start','36odock.service'])
   restart_containers(running)
  finally:
   if samba:run(['/bin/systemctl','start','smbd.service'])
   shutil.rmtree(stage,ignore_errors=True)

def health():
 port=(INSTALL/'port').read_text().strip()
 if not port.isdigit():raise OperationError('Porta inválida.')
 for _ in range(30):
  try:
   with urllib.request.urlopen('http://127.0.0.1:'+port+'/api/health',timeout=2) as r:
    if json.load(r).get('product')=='DOCK360':return
  except Exception:pass
  time.sleep(1)
 raise OperationError('A nova versão não respondeu. Foi iniciada a recuperação.')

ALLOWED=('github.com','raw.githubusercontent.com','objects.githubusercontent.com','release-assets.githubusercontent.com')
def checked_url(url):
 p=urllib.parse.urlparse(url)
 if p.scheme!='https' or p.hostname not in ALLOWED or p.username or p.password or p.port not in [None,443]:raise OperationError('Utilize um ficheiro HTTPS alojado no GitHub.')
 return url
class SafeRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return super().redirect_request(req,fp,code,msg,headers,checked_url(newurl))
def update_install(b,job):
 release=b.get('release',{});version=release.get('version','')
 if not re.fullmatch(r'\d+\.\d+\.\d+',version) or not re.fullmatch('[0-9a-f]{64}',release.get('sha256','')):raise OperationError('Manifesto de atualização inválido.')
 url=checked_url(release.get('packageUrl',''));stage=INSTALL/'releases'/('update-'+version+'-'+job);archive=JOBS/(job+'.zip');previous=(INSTALL/'current').resolve();helper_backup=JOBS/(job+'-helpers');helper_backup.mkdir(mode=0o700)
 try:
  opener=urllib.request.build_opener(SafeRedirect())
  with opener.open(url,timeout=60) as r,archive.open('wb') as f:
   total=0
   while True:
    chunk=r.read(1024*1024)
    if not chunk:break
    total+=len(chunk)
    if total>250*1024*1024:raise OperationError('Limite de atualização: 250 MB.')
    f.write(chunk)
  if hash_file(archive)!=release['sha256']:raise OperationError('A verificação SHA256 da atualização falhou.')
  stage.mkdir(mode=0o755)
  with zipfile.ZipFile(archive) as z:
   total=0
   for info in z.infolist():
    p=Path(info.filename);total+=info.file_size
    if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0]!='DOCK360' or stat.S_ISLNK(info.external_attr>>16) or total>1024**3:raise OperationError('Pacote de atualização inválido.')
   z.extractall(stage)
  release_dir=stage/'DOCK360'
  for required in ['server/server.mjs','dist/index.html','dist/version.json','privileged/36odock-admin.py','privileged/36odock-services.py','privileged/36odock-pty.py']:
   if not (release_dir/required).is_file():raise OperationError('Falta '+required+' no pacote.')
  if load(release_dir/'dist/version.json',{}).get('version')!=version:raise OperationError('Versão do pacote diferente do manifesto.')
  run([INSTALL/'runtime/node/bin/node','--check',release_dir/'server/server.mjs'])
  # A full backup is completed before code activation; failures leave the current release active.
  backup_create(job)
  for name in ['36odock-admin','36odock-services.py','36odock-pty.py']:
   file=LIBEXEC/name
   if file.exists():shutil.copy2(file,helper_backup/name)
  run(['/bin/systemctl','stop','36odock.service'])
  activated=False
  try:
   for source,name in [('36odock-admin.py','36odock-admin'),('36odock-services.py','36odock-services.py'),('36odock-pty.py','36odock-pty.py')]:
    file=LIBEXEC/name;tmp=file.with_name(name+'.next');shutil.copy2(release_dir/'privileged'/source,tmp);os.chmod(tmp,0o755);os.replace(tmp,file)
   next_link=INSTALL/'current.next';next_link.unlink(missing_ok=True);next_link.symlink_to(release_dir);os.replace(next_link,INSTALL/'current');activated=True
   run(['/bin/systemctl','start','36odock.service']);health();write_json(ROOT/'previous-release.json',{'path':str(previous)});return {'version':version,'previous':str(previous)}
  except:
   for name in ['36odock-admin','36odock-services.py','36odock-pty.py']:
    if (helper_backup/name).exists():shutil.copy2(helper_backup/name,LIBEXEC/name)
   if activated:
    link=INSTALL/'current.rollback';link.unlink(missing_ok=True);link.symlink_to(previous);os.replace(link,INSTALL/'current')
   run(['/bin/systemctl','restart','36odock.service']);raise
 finally:
  archive.unlink(missing_ok=True)
  if stage.exists() and not (INSTALL/'current').resolve().is_relative_to(stage):shutil.rmtree(stage,ignore_errors=True)

def rollback_release():
 previous=Path(load(ROOT/'previous-release.json',{}).get('path',''))
 if not previous.is_absolute() or not previous.resolve().is_relative_to(INSTALL/'releases') or not (previous/'server/server.mjs').exists():raise OperationError('Não existe uma versão anterior disponível.')
 current=(INSTALL/'current').resolve();run(['/bin/systemctl','stop','36odock.service'])
 try:
  link=INSTALL/'current.rollback';link.unlink(missing_ok=True);link.symlink_to(previous);os.replace(link,INSTALL/'current');run(['/bin/systemctl','start','36odock.service']);health();write_json(ROOT/'previous-release.json',{'path':str(current)})
 except:
  link=INSTALL/'current.rollback';link.unlink(missing_ok=True);link.symlink_to(current);os.replace(link,INSTALL/'current');run(['/bin/systemctl','restart','36odock.service']);raise
 return {'rolledBack':True}

def remote(b):
 if not shutil.which('tailscale'):return {'installed':False,'state':'Não instalado. Execute novamente o instalador e escolha Tailscale.'}
 action=b.get('action','status')
 if action=='connect':
  # The root process returns immediately; the admin completes login at the provider.
  run(['/bin/systemctl','start','tailscaled.service']);run(['/usr/bin/tailscale','up','--timeout=5s'],timeout=10,check=False)
 elif action=='disconnect':run(['/usr/bin/tailscale','down'])
 elif action=='serve':run(['/usr/bin/tailscale','serve','--bg','--https=443','http://127.0.0.1:'+str(int((INSTALL/'port').read_text().strip()))],timeout=30)
 elif action=='unserve':run(['/usr/bin/tailscale','serve','reset'])
 elif action!='status':raise OperationError('Operação de acesso remoto inválida.')
 raw=json.loads(run(['/usr/bin/tailscale','status','--json'],check=False) or '{}');me=raw.get('Self',{});login=raw.get('AuthURL','');p=urllib.parse.urlparse(login)
 if login and (p.scheme!='https' or not (p.hostname=='login.tailscale.com' or p.hostname=='controlplane.tailscale.com')):login=''
 return {'installed':True,'state':raw.get('BackendState','Desligado'),'ips':raw.get('TailscaleIPs',[]),'dns':me.get('DNSName','').rstrip('.'),'loginUrl':login,'serve':run(['/usr/bin/tailscale','serve','status'],check=False).strip()}

def sync_teams(broker):
 import grp,pwd
 TEAMS.mkdir(mode=0o711,exist_ok=True);teams=load(DATA/'teams.json',[]);users=load(DATA/'users.json',[]);valid={u['username'] for u in users}
 known_groups=[]
 for team in teams:
  if not re.fullmatch('[a-z][a-z0-9-]{2,39}',team['id']):raise OperationError('Identificador de equipa inválido.')
  name='d36t_'+hashlib.sha256(team['id'].encode()).hexdigest()[:12];folder=TEAMS/team['id']
  try:group=grp.getgrnam(name)
  except KeyError:run(['/usr/sbin/groupadd','--system',name]);group=grp.getgrnam(name)
  names=[broker.account(m['username'])[0].pw_name for m in team['members'] if m['username'] in valid];run(['/usr/bin/gpasswd','-M',','.join(names),name]);known_groups.append(name)
  if folder.is_symlink():raise OperationError('Pasta de equipa inválida.')
  folder.mkdir(mode=0o2770,exist_ok=True);os.chown(folder,0,group.gr_gid);os.chmod(folder,0o2770)
  # Native read-only memberships use POSIX ACLs; Samba enforces the same access.
  for root,dirs,files in os.walk(folder,followlinks=False):
   run(['/usr/bin/setfacl','-b',root]);run(['/usr/bin/setfacl','-k',root]);os.chown(root,0,group.gr_gid);os.chmod(root,0o2770)
   for file in files:
    p=Path(root)/file
    if not p.is_symlink():os.chown(p,0,group.gr_gid);os.chmod(p,0o660);run(['/usr/bin/setfacl','-b',p])
   for member in team['members']:
    if member['username'] not in valid:continue
    u=broker.account(member['username'])[0];access='rwx' if member['access']=='write' else 'r-x'
    run(['/usr/bin/setfacl','-m','u:'+str(u.pw_uid)+':'+access+',d:u:'+str(u.pw_uid)+':'+access,root])
    for file in files:
     p=Path(root)/file
     if not p.is_symlink():run(['/usr/bin/setfacl','-m','u:'+str(u.pw_uid)+':'+('rw-' if member['access']=='write' else 'r--'),p])
 # Remove memberships of deleted teams; files remain for recovery by the administrator.
 for group in grp.getgrall():
  if group.gr_name.startswith('d36t_') and group.gr_name not in known_groups:run(['/usr/bin/gpasswd','-M','',group.gr_name])
 # Close active SMB handles after permission changes, including removed shares.
 shares={'equipa-'+t['id'] for t in teams}
 try:shares.update(re.findall(r'^\[(equipa-[a-z0-9-]+)\]$',Path('/etc/samba/36odock.conf').read_text(),re.M))
 except FileNotFoundError:pass
 for share in shares:run(['/usr/bin/smbcontrol','all','close-share',share],check=False)
 return {'ok':True}

def team_owner(b,broker):
 import grp,types
 teams=load(DATA/'teams.json',[]);team=next((t for t in teams if t['id']==b.get('team')),None);users=load(DATA/'users.json',[]);u=next((u for u in users if u['username']==b['username']),None)
 if not team or not u:raise OperationError('Equipa ou utilizador inválido.')
 if u['role']!='admin':
  m=next((m for m in team['members'] if m['username']==u['username']),None)
  if not m or (b.get('op') not in ['list','download'] and m['access']!='write'):raise OperationError('Sem acesso à pasta da equipa.')
 folder=TEAMS/team['id'];group=grp.getgrnam('d36t_'+hashlib.sha256(team['id'].encode()).hexdigest()[:12])
 return folder,types.SimpleNamespace(pw_uid=0,pw_gid=group.gr_gid,team=True)

def team_samba_lines(broker):
 lines=[];users={u['username'] for u in load(DATA/'users.json',[])}
 for t in load(DATA/'teams.json',[]):
  names=[broker.name_for(m['username']) for m in t['members'] if m['username'] in users];writers=[broker.name_for(m['username']) for m in t['members'] if m['username'] in users and m['access']=='write']
  if not names:continue
  lines+=['[equipa-'+t['id']+']','    path = '+str(TEAMS/t['id']),'    valid users = '+' '.join(names),'    write list = '+' '.join(writers),'    read only = yes','    browseable = yes','    guest ok = no','    create mask = 0660','    directory mask = 0770','    inherit acls = yes','    follow symlinks = no','    wide links = no','']
 return lines

def enqueue(b):
 JOBS.mkdir(mode=0o700,parents=True,exist_ok=True);id=uuid.uuid4().hex;request={'id':id,'request':b,'operation':b['action'],'status':'pending','created':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};write_json(JOBS/(id+'.json'),request)
 run(['/bin/systemd-run','--collect','--unit=dock360-job-'+id,'/usr/bin/python3','-I','/usr/local/libexec/36odock-admin','--job',id]);return {'job':id}

def job_run(id):
 if not re.fullmatch('[0-9a-f]{32}',id):raise OperationError('Operação inválida.')
 file=JOBS/(id+'.json');record=load(file);request=record['request'];lock=ROOT/'operations.lock'
 with lock.open('a') as f:
  try:
   fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);write_json(ROOT/'operations-active.json',{'pid':os.getpid(),'id':id,'operation':request['action']});os.chmod(ROOT/'operations-active.json',0o644);record['status']='running';write_json(file,record);op=request['action']
   if op=='create':result=backup_create(id)
   elif op=='restore':result=backup_restore(request,id)
   elif op=='update':result=update_install(request,id)
   elif op=='rollback':result=rollback_release()
   else:raise OperationError('Operação inválida.')
   record.update(status='succeeded',result=result)
  except Exception as e:record.update(status='failed',error=str(e)[:400])
  finally:
   active=load(ROOT/'operations-active.json',{});
   if active.get('id')==id:(ROOT/'operations-active.json').unlink(missing_ok=True)
   record.pop('request',None);record['finished']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());write_json(file,record)

def dispatch(b,broker):
 configure(broker.DATA,broker.HOMES);op=b.get('op')
 if op=='disks':
  if b.get('action','list')=='list':return disk(b)
  with (ROOT/'operations.lock').open('a') as lock:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:raise OperationError('Existe uma cópia, restauro ou atualização em curso.')
   return disk(b)
 if op=='teams':
  result=sync_teams(broker);users=load(DATA/'users.json',[])
  if users:broker.samba({'action':'sync','username':users[0]['username']})
  return result
 if op=='remote':return remote(b)
 if op=='jobs':
  JOBS.mkdir(mode=0o700,exist_ok=True);jobs=[]
  for file in sorted(JOBS.glob('*.json'),key=lambda f:f.stat().st_mtime,reverse=True)[:50]:
   r=load(file);r.pop('request',None);jobs.append(r)
  return {'jobs':jobs}
 if op=='backups':
  if b.get('action')=='destination':
   id=b.get('uuid')
   if id and not any(d['uuid']==id and d['manageable'] and d['mounts']==[str(MOUNTS/id)] for d in disk_rows()):raise OperationError('Selecione um disco montado pelo DOCK360.')
   with (ROOT/'operations.lock').open('a') as lock:
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise OperationError('Existe uma cópia, restauro ou atualização em curso.')
    write_json(ROOT/'backup-destination.json',{'uuid':id});return backup_list()
  return backup_list()
 if op=='job' and b.get('action') in ['create','restore','update','rollback']:return enqueue(b)
 raise OperationError('Operação não permitida.')
