# DOCK360 0.6.0 — 360LAB
Painel para Linux e Raspberry Pi OS de 64 bits. O pacote não contém as aplicações próprias 360DOC, 360GTF, 360SCIE, 360Obras ou 360Gabinetes.

## Instalação recomendada
No Raspberry Pi OS Bookworm ou Trixie de 64 bits, extraia o pacote RaspberryPi e execute `bash install.sh`. O assistente instala Node.js ARM64, Docker e Samba nativo, configura a conta inicial, pastas privadas, o assistente de administração e o arranque automático. O ZIP genérico contém o código; as funções privilegiadas requerem o instalador Raspberry Pi.

## Aparência e ícones
370 ícones originais incluídos localmente, com origem registada em dist/icon-manifest.json. As marcas pertencem aos respetivos titulares. Não há dependência de CDN para os ícones. As bibliotecas xterm.js, addon-fit e SunCalc são distribuídas com os avisos de licença na pasta vendor.
Definições > Ambiente visual: Dia, Noite e Automático. O modo automático calcula nascer/pôr do sol a partir de latitude e longitude e verifica a mudança a cada 30 segundos, ao regressar à página e quando o dispositivo muda de tema. Defina coordenadas manualmente ou permita geolocalização. Sem localização, acompanha o tema do dispositivo e informa essa condição. A hora apresentada é a do dispositivo. Cálculo solar com SunCalc 2.1.1; não requer API externa.

## Login e perfis
Palavras-passe com salt/scrypt, sessões HttpOnly/SameSite=Strict de oito horas, limite de tentativas. Administrador: funções de sistema, terminal, reinício, contas, catálogos e aplicações. Gestor: aplicações preparadas e a sua pasta privada. Consulta: consulta das aplicações e leitura/escrita na sua pasta privada. O perfil Consulta não dá acesso ao sistema operativo.
A demonstração online é uma simulação local: admin, gestor ou consulta / DemoDOCK360!. Não executa operações no sistema. Os ficheiros da demonstração são separados por conta numa nova base IndexedDB; o antigo armazenamento partilhado não é reutilizado.

## Ficheiros e privacidade
Cada utilizador tem uma pasta individual, identificada por um hash do nome. No instalador, cada pasta pertence a uma conta Linux dedicada, com modo 0700 e ficheiros 0600. A API usa sempre a identidade autenticada, nunca uma identidade enviada pelo navegador. O administrador dispõe de A minha pasta e Sistema /; o acesso de administração do sistema é uma exceção à privacidade das contas normais.
Limite de 20 MB por transferência; pastas só são eliminadas quando vazias. Pré-visualização de imagens/textos e edição de texto até 1 MB. Edições exigem o hash do conteúdo anterior, detetando conflitos. As ligações simbólicas são recusadas nas pastas privadas com percursos por descritores de diretório e O_NOFOLLOW. Acesso a /proc, /sys, /dev e ficheiros especiais não é fornecido pelo gestor de ficheiros. Alterações ao sistema requerem privilégios e confirmação na interface.
Os ficheiros partilhados da versão anterior ficam preservados em /var/lib/36odock/files, acessíveis à administração. Não são distribuídos automaticamente pelas novas pastas privadas. Não existe lixeira.

## Terminal e reinício
Terminal exclusivo do administrador, com xterm.js e uma shell Bash real através de PTY. Suporta entrada, redimensionamento, saída e Ctrl+C. A sessão está ligada à sessão de login, termina ao sair/navegar para outra secção e expira após 15 minutos sem entrada. O terminal administrativo executa como root: os comandos afetam o equipamento.
Definições > Sistema e partilha > Reiniciar sistema: exige escrever REINICIAR e agenda o reinício com systemd. A demonstração apenas apresenta o comportamento de exemplo. O teste automático do reinício usa um executor simulado; nenhum equipamento foi reiniciado na validação.

## Samba nativo
Instala o serviço smbd do Raspberry Pi OS, sem contentor. Integra partilhas privadas em /etc/samba/36odock.conf através de include no smb.conf existente. Cada partilha usa valid users, sem guest, máscaras 0600/0700 e sem seguir links. Uma configuração Samba de domínio requer integração manual; o instalador não a substitui.
Cada pessoa abre Definições > Partilha Samba para definir uma palavra-passe de rede independente da palavra-passe web. A interface mostra o utilizador de rede gerado e os endereços Windows e smb://. As pastas privadas e as pastas de equipa autorizadas são partilhadas; a raiz do sistema não é exposta por Samba. Eliminar uma conta do painel desativa o respetivo acesso Samba, preservando os dados. Criar/alterar contas atualiza a configuração de partilhas.
O nome da conta de rede difere do login web e é apresentado na interface. Se alterar a palavra-passe do painel, a palavra-passe Samba não é alterada. Não publique SMB/porta445 na Internet.

## Privilégios
O serviço web continua como dock36. O instalador cria um assistente root-owned em /usr/local/libexec/36odock-admin e regras sudo limitadas a esse executável, com nenhum argumento ou apenas terminal. As APIs de sistema exigem administrador e rejeitam origens POST diferentes. O código do assistente pertence a root e não pode ser alterado pela conta web.
Como a conta dock36 tem acesso Docker e ao assistente, o serviço integra a fronteira de confiança de administração do anfitrião. Apenas administradores de confiança devem receber esse perfil. O painel está preparado para a rede local; configure HTTPS/VPN para acesso externo.

## Dados e migração
Configuração: /var/lib/36odock/config. Pastas pessoais: /var/lib/36odock/homes. Ficheiros partilhados antigos: /var/lib/36odock/files. Backups de configuração: /var/lib/36odock/backups. O novo módulo de cópias inclui os volumes das aplicações Docker geridas. O instalador preserva contas, pastas e versões anteriores de instalações geridas por ele; não substitui automaticamente uma instalação manual.
Para execução manual sem assistente: Node.js22+, definir DOCK_ADMIN_PASSWORD (12+ caracteres), executar node server/server.mjs. Definir DOCK_HOMES_ROOT para a raiz de pastas pessoais; por omissão data/homes. O acesso Sistema fica limitado às permissões do processo; terminal, Samba e reinício indicam indisponibilidade sem o assistente instalado. Não execute o serviço web como root.

## Validação e limites
Testes: `node tests/security-v04.mjs` e `python3 tests/privileged-v04.py`. Incluem autenticação HTTP, isolamento entre duas contas, permissões para sistema/terminal/Samba/reinício, conflitos de edição, symlinks, renomeação sem sobrescrita, permissões Unix e PTY real com comandos inofensivos. Os testes não instalam nem reiniciam serviços do anfitrião.
Foram inspecionados no navegador os ícones, os temas dia/noite e as horas solares, com dados de teste. A instalação integral, o serviço Samba e a integração sudo/systemd ainda precisam de validação num Raspberry Pi físico.
Existem dez instaladores preparados: Nextcloud, Jellyfin, Home Assistant, Uptime Kuma, n8n, Vaultwarden, Syncthing, File Browser, Audiobookshelf e FreshRSS. As quatro novas receitas utilizam o canal latest oficial; a arquitetura é validada pelo Docker na descarga. A biblioteca mantém 370 referências. As restantes exigem adaptação. As aplicações são publicadas apenas em loopback; para abrir a interface fora do anfitrião, configure o endereço/proxy privado da aplicação. O acesso remoto integrado do painel não publica automaticamente todas as aplicações.

## Nome e compatibilidade
O nome comercial é DOCK360. Identificadores técnicos, nomes de serviços, contas Linux, diretórios e chaves locais existentes mantêm-se para preservar instalações e dados anteriores.

## Novidades 0.5.0 — Sistema
- Monitorização: CPU por diferença de amostras, memória disponível Linux, temperatura sysfs quando disponível, espaço do volume de dados, carga e uptime. Atualização de cinco segundos enquanto a página está aberta.
- Segurança: TOTP SHA1, seis dígitos, 30 segundos, janela ±1, rejeição de passos reutilizados e dez códigos de recuperação de uso único. Ativação com confirmação do código, palavra-passe atual e revogação das outras sessões. A chave é guardada apenas no ficheiro de contas protegido; cópias incluem-na. Alteração da palavra-passe e encerramento das outras sessões pelo utilizador.
- Equipas: administração de membros com leitura ou edição; acesso pelo gestor de ficheiros e Samba; grupos Linux e ACLs. Remover uma equipa conserva os ficheiros para recuperação pelo administrador. As ligações Samba existentes são fechadas na sincronização para aplicar novas permissões.
- Atividade: login aceite/recusado, alterações de contas, operações de ficheiros, aplicações, abertura de terminal, reinício e manutenção. Últimos 1 000 eventos no painel, pesquisa e CSV. Rotação local de dois ficheiros até cerca de 5 MB cada; sem passwords, chaves 2FA ou comandos do terminal.
- Assistente de cinco passos: nome persistente do servidor e localização; orientação para segurança, discos e backups. Não ativa silenciosamente dois fatores nem formata discos.

## Backups e restauro
Sistema > Backups. Cópias manuais tar.gz verificadas por SHA256 de config, homes, teams e volumes de aplicações com a etiqueta gerida. Os contentores em execução e o Samba são parados e retomados mesmo se a cópia falhar. O sistema operativo, imagens Docker, contentores de outras origens e ficheiros antigos em /var/lib/36odock/files não estão incluídos. Não é uma imagem integral do cartão SD.
Destino local /var/lib/36odock/backups ou partição USB montada pelo DOCK360. Se o disco externo escolhido estiver ausente, a operação falha e não grava silenciosamente no cartão SD. Os ficheiros de cópia têm modo 0600; não são cifrados. Copie-os para outro suporte e proteja fisicamente o disco. Não há agendamento automático nem retenção automática nesta versão.
O restauro exige palavra-passe atual e RESTAURAR. Instale previamente as mesmas aplicações/versões para recriar contentores e volumes. O pacote é verificado, extraído numa área de preparação com filtro seguro, e as pastas anteriores ficam retidas para recuperação. O painel reinicia e as sessões terminam. Entre com a conta e 2FA da cópia; redefina a palavra-passe Samba. Se a saúde HTTP falhar, as pastas anteriores são repostas. As contas Linux são reprovisionadas e as permissões de equipas são sincronizadas.
Operações longas correm em unidades systemd independentes do painel. Consulte o estado em Operações recentes e os registos de dock360-job-* no journal. As cópias/restauros/atualizações e alterações de montagem/destino são coordenadas por bloqueio de operação. Não altere ficheiros pelo terminal nem outras ferramentas durante uma cópia.

## Atualizações pelo painel e GitHub
Sistema > Atualizações. Publique DOCK360-servidor.zip num repositório GitHub e um manifesto release.json no mesmo repositório. Consulte dist/release-example.json: substitua o utilizador e o endereço pelo seu repositório, mantendo o SHA256 do pacote publicado. O painel aceita o endereço raw HTTPS de release.json, valida versão, SHA256 e origem do ZIP no mesmo repositório. Não existe um repositório público oficial pré-configurado.
A instalação descarrega um ZIP até 250 MB, verifica SHA256 e caminhos, prepara a versão, cria uma cópia completa e só depois altera a versão ativa. Se a saúde falhar, repõe o código e os assistentes anteriores. A versão anterior pode ser reativada pelo painel com palavra-passe e REVERTER. Dados e código têm recuperação separada; uma futura migração de formato poderá exigir o restauro dos dados. Não existem atualizações automáticas em segundo plano nem assinatura digital de versões; use apenas o repositório que controla.

## Discos e acesso remoto
Sistema > Discos: identificação com lsblk, montagem/desmontagem de partições de dados USB/SATA/NVMe reconhecidas e proteção dos discos do sistema. Montagem em /mnt/dock360/UUID com nosuid,nodev,noexec. Não formata nem elimina partições, não altera fstab e não gere RAID nem particionamento. A montagem é manual após cada arranque.
O instalador oferece Tailscale por opção (s/N), através do repositório APT oficial assinado. Sistema > Acesso remoto permite associar o equipamento, mostrar endereços privados, desligar e ativar HTTPS por Tailscale Serve. O utilizador autoriza a conta no fornecedor e instala o cliente nos seus dispositivos. HTTPS requer MagicDNS/certificados na conta. Não abre portas no router, não ativa Funnel, rotas de sub-rede ou nó de saída. Usa a configuração Serve deste equipamento; reserve-a para DOCK360.

## Validação 0.5.0
node tests/check.mjs
node tests/features-v05.mjs
node tests/solar-v04.mjs
python3 tests/privileged-v04.py
python3 tests/operations-v05.py
Os testes incluem RFC 6238, APIs HTTP reais, isolamento e revogação de equipas, uso único/replay de 2FA, recuperação de sessão, redação do registo, arquivos de backup e restauro real de ficheiros numa pasta temporária com falha de saúde e rollback. Comandos de discos, Docker, Samba e systemd são simulados. O painel e assistente foram inspecionados no navegador. A validação integral num Raspberry Pi físico, com USB, Samba, Tailscale e Docker reais, continua necessária.

## Idiomas e região — 0.6.0
A interface inclui sete pacotes locais: pt-PT, pt-BR, en, es, fr, de e it. O navegador escolhe o idioma inicial; qualquer pessoa pode escolher outro no formulário de login. Definições > Idioma e região guarda idioma e fuso horário por conta no servidor real; a demonstração guarda por conta neste navegador. A seleção Auto acompanha o idioma/fuso do dispositivo. Datas, horas e números usam Intl com o formato regional selecionado. Não altera o relógio ou o fuso horário do sistema operativo.
Os pacotes estão em dist/locales e não utilizam um serviço externo de tradução. Existem 535 mensagens de base; espanhol, francês, alemão e italiano incluem 465 traduções e recorrem ao inglês para os avisos técnicos restantes. Textos novos ainda sem chave podem aparecer em português. Os nomes dos ficheiros, nomes atribuídos pelo utilizador, URLs, chaves, passwords e comandos do terminal não são traduzidos. Aplicações de terceiros, catálogo de origem, documentação e instalador de terminal têm idiomas próprios; esta alteração localiza o painel DOCK360.
O administrador pode importar outro pacote JSON em Definições > Idioma e região > Adicionar pacote de idioma. O modelo contém exemplos; use pt-PT.json como base para traduzir todas as mensagens, alterando id, name e locale. Campos: id BCP47 canónico (ex. nl), name, locale (ex. nl-NL), direction ltr/rtl e messages, um objeto texto original → tradução. Preserve parâmetros como {count}. Os pacotes não executam HTML ou JavaScript; não podem substituir os idiomas oficiais. Limite de ficheiro no painel: 500 KB, até 2 000 mensagens. Na demonstração, a importação fica apenas neste navegador.
No servidor, os pacotes adicionais ficam em config/languages e as preferências em config/locale-UTILIZADOR.json. A API exige autenticação e só o administrador pode instalar pacotes; cada utilizador só altera as suas preferências. As cópias de config incluem estas definições. Mudanças de idioma não alteram perfis ou requisitos 2FA. A demonstração continua a pedir apenas utilizador/palavra-passe.
Validação: node tests/languages.mjs verifica os sete pacotes, parâmetros, entrega HTTP, isolamento de preferências por utilizador, fusos, CSRF, importação administrativa, persistência e rejeição de código/caminhos inválidos. Foram verificados no navegador o login em inglês/português do Brasil, o painel em francês e o fuso Asia/Tokyo. Compilar alterações de traduções com python3 scripts/build-languages.py.
