#!/usr/bin/env bash
# DOCK360 Raspberry Pi installer — version 0.6.0
set -Eeuo pipefail
umask 022
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
TASK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_ROOT=/opt/36odock
STATE_ROOT=/var/lib/36odock
UNIT=/etc/systemd/system/36odock.service
MARKER='# Managed by DOCK360 Raspberry installer'
fail(){ printf '\nErro: %s\n' "$*" >&2; exit 1; }
log(){ printf '\n[%s] %s\n' "$1" "$2"; }
if [[ ${1:-} == --help ]]; then
 printf 'DOCK360 Raspberry Pi — instalação guiada\n\nExecute: bash install.sh\nVerificar requisitos sem instalar: bash install.sh --check\nRequer Raspberry Pi OS 64-bit Bookworm/Trixie, Internet e sudo.\n'; exit 0
fi
[[ $# -eq 0 || ( $# -eq 1 && $1 == --check ) ]] || fail 'Opção desconhecida. Utilize --help.'
[[ $(uname -s) == Linux ]] || fail 'Este instalador requer Linux.'
[[ $(uname -m) == aarch64 ]] || fail 'Requer Raspberry Pi OS de 64 bits (aarch64). Não instale sobre um sistema de 32 bits.'
[[ -r /etc/os-release ]] || fail 'Não foi possível identificar o sistema operativo.'
# shellcheck source=/dev/null
source /etc/os-release
[[ ${ID:-} == debian || ${ID:-} == raspbian ]] || fail 'Instalador preparado para Raspberry Pi OS/Debian.'
[[ ${VERSION_CODENAME:-} == bookworm || ${VERSION_CODENAME:-} == trixie ]] || fail 'Requer Raspberry Pi OS Bookworm ou Trixie.'
[[ -d /run/systemd/system ]] || fail 'É necessário um sistema com systemd em execução.'
[[ -r "$TASK_DIR/payload.tar.gz" && -r "$TASK_DIR/payload.sha256" ]] || fail 'Extraia o ZIP completo antes de executar install.sh.'
(cd "$TASK_DIR" && sha256sum --status -c payload.sha256) || fail 'O pacote está incompleto ou corrompido. Descarregue-o novamente.'
if [[ -e $UNIT ]] && ! grep -qE '^# Managed by (DOCK360|36ODOCK) Raspberry installer$' "$UNIT"; then fail 'Já existe um serviço 36odock instalado por outro método. Preserve os dados e remova ou migre esse serviço antes de continuar; este instalador não o substitui.'; fi
if command -v testparm >/dev/null && [[ -r /etc/samba/smb.conf ]]; then
 SAMBA_ROLE=$(testparm -s --parameter-name='server role' /etc/samba/smb.conf 2>/dev/null || true)
 [[ -z $SAMBA_ROLE || $SAMBA_ROLE == 'standalone server' ]] || fail 'Esta instalação Samba requer integração manual (não é um servidor autónomo).'
fi
if id dock36 &>/dev/null; then
 [[ $(getent passwd dock36 | cut -d: -f6) == "$STATE_ROOT" ]] || fail 'Já existe um utilizador dock36 de outra instalação.'
fi
if [[ ${1:-} == --check ]]; then
 printf 'Requisitos de arquitetura, sistema e integridade: OK.\nPlano: instalar dependências em falta, criar conta do serviço, configurar login, ativar arranque automático e testar HTTP.\nNão foi alterado o sistema.\n';exit 0
fi
if [[ $EUID -ne 0 ]]; then exec sudo -- bash "$TASK_DIR/install.sh"; fi
exec 3<>/dev/tty || fail 'Execute no terminal, não através de curl | bash.'
TMP_DIR=$(mktemp -d /tmp/36odock-install.XXXXXX)
ACTIVATED=0
PREVIOUS=''
PREVIOUS_ACTIVE=0
cleanup(){
 local code=$?
 unset ADMIN_PASSWORD ADMIN_CONFIRM
 if [[ $code -ne 0 && $ACTIVATED -eq 1 ]]; then
  systemctl stop 36odock.service >/dev/null 2>&1 || true
  if [[ -n $PREVIOUS ]]; then
   ln -sfn "$PREVIOUS" "$INSTALL_ROOT/current.rollback"
   mv -Tf "$INSTALL_ROOT/current.rollback" "$INSTALL_ROOT/current"
  else rm -f "$INSTALL_ROOT/current"; fi
  if [[ -r "$TMP_DIR/previous.service" ]]; then
   cp "$TMP_DIR/previous.service" "$UNIT"
  else systemctl disable 36odock.service >/dev/null 2>&1 || true; rm -f "$UNIT"; fi
  systemctl daemon-reload || true
  if [[ $PREVIOUS_ACTIVE -eq 1 ]]; then systemctl start 36odock.service || true; fi
  printf '\nA ativação falhou; foi reposta a configuração anterior. As contas, ficheiros e dependências instaladas foram preservados.\n' >&2
 fi
 rm -rf -- "$TMP_DIR"
}
trap cleanup EXIT
trap 'printf "\nInstalação interrompida. Consulte a mensagem anterior.\n" >&2' ERR
printf '\nDOCK360 · Instalação guiada para Raspberry Pi\n\nInstala Node.js, Docker e Samba, cria um serviço e disponibiliza o painel na rede local. O administrador terá acesso ao sistema e terminal.\nOs serviços Docker continuam limitados ao próprio equipamento.\nA conta técnica terá acesso Docker, equivalente a administração do anfitrião.\nNão altera ou apaga dados de outras aplicações.\n\n' >&3
if [[ -r "$STATE_ROOT/config/users.json" ]]; then
 printf 'Foi encontrada uma instalação gerida por este instalador. As contas e os ficheiros serão mantidos.\n' >&3
else
 read -r -p 'Nome do administrador [admin]: ' ADMIN_USER <&3
 ADMIN_USER=${ADMIN_USER:-admin}
 [[ $ADMIN_USER =~ ^[a-zA-Z0-9_.-]{3,40}$ ]] || fail 'Utilize 3 a 40 letras, números, pontos, hífen ou sublinhado.'
 while true; do
  read -r -s -p 'Palavra-passe (12 a 256 caracteres): ' ADMIN_PASSWORD <&3; printf '\n' >&3
  read -r -s -p 'Confirmar palavra-passe: ' ADMIN_CONFIRM <&3; printf '\n' >&3
  if [[ ${#ADMIN_PASSWORD} -ge 12 && ${#ADMIN_PASSWORD} -le 256 && $ADMIN_PASSWORD == "$ADMIN_CONFIRM" ]]; then break; fi
  printf 'As palavras-passe devem coincidir e ter entre 12 e 256 caracteres.\n' >&3
 done
 unset ADMIN_CONFIRM
fi
PORT=3600
if [[ -r "$INSTALL_ROOT/port" ]]; then read -r PORT < "$INSTALL_ROOT/port"; fi
read -r -p "Porta do painel [$PORT]: " ANSWER <&3
PORT=${ANSWER:-$PORT}
[[ $PORT =~ ^[0-9]{4,5}$ && $PORT -ge 1024 && $PORT -le 65535 ]] || fail 'Escolha uma porta entre 1024 e 65535.'
if [[ $PORT == 0* ]]; then fail 'A porta não deve começar por zero.'; fi
if systemctl is-active --quiet 36odock.service; then PREVIOUS_ACTIVE=1; fi
# Reject conflicting listeners before modifying the existing service.
if command -v ss >/dev/null && ss -H -ltn "sport = :$PORT" | grep -q .; then
 if [[ $PREVIOUS_ACTIVE -ne 1 || ! -r "$INSTALL_ROOT/port" || $(cat "$INSTALL_ROOT/port") != "$PORT" ]]; then fail "A porta $PORT já está ocupada."; fi
fi
read -r -p 'Instalar Tailscale para acesso remoto privado? [s/N]: ' REMOTE_CHOICE <&3
log 1/6 'A preparar dependências…'
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl xz-utils tar unzip iproute2 sudo python3 samba samba-common-bin acl util-linux exfatprogs ntfs-3g
python3 -c 'import tarfile; assert hasattr(tarfile,"data_filter"), "Atualize Python 3 para obter o filtro seguro de restauro."'
if [[ ${REMOTE_CHOICE,,} == s || ${REMOTE_CHOICE,,} == sim ]]; then
 if ! command -v tailscale >/dev/null; then
  if [[ ! -f /etc/apt/sources.list.d/tailscale.list ]]; then
   curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' --tlsv1.2 "https://pkgs.tailscale.com/stable/debian/$VERSION_CODENAME.noarmor.gpg" -o "$TMP_DIR/tailscale-keyring.gpg"
   curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' --tlsv1.2 "https://pkgs.tailscale.com/stable/debian/$VERSION_CODENAME.tailscale-keyring.list" -o "$TMP_DIR/tailscale.list"
   install -m 0644 "$TMP_DIR/tailscale-keyring.gpg" /usr/share/keyrings/tailscale-archive-keyring.gpg
   install -m 0644 "$TMP_DIR/tailscale.list" /etc/apt/sources.list.d/tailscale.list
  fi
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y tailscale
 fi
 systemctl enable --now tailscaled.service
 printf '\nTailscale instalado. Associe a sua conta em Sistema → Acesso remoto depois de iniciar sessão.\n' >&3
fi
log 2/6 'A verificar Docker…'
if ! command -v docker >/dev/null; then
 for package in docker.io docker-compose podman-docker containerd runc; do
  if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then fail "Foi encontrado $package. Reveja a instalação Docker existente; não removemos pacotes automaticamente."; fi
 done
 if [[ -e /etc/apt/sources.list.d/docker.sources || -e /etc/apt/sources.list.d/docker.list ]]; then fail 'Existe uma configuração de repositório Docker. Conclua a instalação Docker existente e volte a executar o instalador.'; fi
 install -m 0755 -d /etc/apt/keyrings
 curl --fail --silent --show-error --location --proto '=https' --tlsv1.2 https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/36odock-docker.asc
 chmod 0644 /etc/apt/keyrings/36odock-docker.asc
 cat > /etc/apt/sources.list.d/36odock-docker.sources <<REPO
Types: deb
URIs: https://download.docker.com/linux/debian
Suites: $VERSION_CODENAME
Components: stable
Architectures: arm64
Signed-By: /etc/apt/keyrings/36odock-docker.asc
REPO
 apt-get update
 DEBIAN_FRONTEND=noninteractive apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
systemctl enable --now docker.service
docker info >/dev/null || fail 'O Docker não está operacional.'
log 3/6 'A preparar Node.js 22 para ARM64…'
install -d -m 0755 "$INSTALL_ROOT/runtime" "$INSTALL_ROOT/releases"
NODE="$INSTALL_ROOT/runtime/node/bin/node"
if [[ ! -x $NODE ]] || ! "$NODE" -e 'process.exit(Number(process.versions.node.split(".")[0])>=22?0:1)'; then
 curl --fail --silent --show-error --location --proto '=https' --tlsv1.2 https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt -o "$TMP_DIR/SHASUMS256.txt"
 NODE_FILE=$(awk '$2 ~ /^node-v22\.[0-9]+\.[0-9]+-linux-arm64\.tar\.xz$/ {print $2}' "$TMP_DIR/SHASUMS256.txt")
 [[ $NODE_FILE =~ ^node-v22\.[0-9]+\.[0-9]+-linux-arm64\.tar\.xz$ ]] || fail 'Não foi possível identificar o binário oficial Node.js ARM64.'
 curl --fail --silent --show-error --location --proto '=https' --tlsv1.2 "https://nodejs.org/dist/latest-v22.x/$NODE_FILE" -o "$TMP_DIR/$NODE_FILE"
 (cd "$TMP_DIR" && awk -v file="$NODE_FILE" '$2 == file' SHASUMS256.txt | sha256sum -c -) || fail 'A verificação SHA256 do Node.js falhou.'
 tar -xJf "$TMP_DIR/$NODE_FILE" -C "$TMP_DIR"
 NODE_DIR=${NODE_FILE%.tar.xz}
 NODE_TARGET="$NODE_DIR-$$"
 cp -a "$TMP_DIR/$NODE_DIR" "$INSTALL_ROOT/runtime/$NODE_TARGET"
 ln -sfn "$NODE_TARGET" "$INSTALL_ROOT/runtime/node"
fi
"$NODE" --version
log 4/6 'A instalar os ficheiros e configurar a conta…'
getent group docker >/dev/null || groupadd --system docker
if ! id dock36 &>/dev/null; then useradd --system --user-group --home-dir "$STATE_ROOT" --shell /usr/sbin/nologin dock36; fi
usermod -aG docker dock36
install -d -o dock36 -g dock36 -m 0750 "$STATE_ROOT" "$STATE_ROOT/config" "$STATE_ROOT/files"
RELEASE="$INSTALL_ROOT/releases/$(date -u +%Y%m%dT%H%M%SZ)-$$"
install -d -m 0755 "$RELEASE"
tar -xzf "$TASK_DIR/payload.tar.gz" -C "$RELEASE" --no-same-owner
unzip -q "$RELEASE/app.zip" -d "$TMP_DIR/unpacked"
cp -a "$TMP_DIR/unpacked/DOCK360/." "$RELEASE/"
mv "$RELEASE/app.zip" "$RELEASE/dist/DOCK360-servidor.zip"
chown -R root:root "$RELEASE"
find "$RELEASE" -type d -exec chmod 0755 {} +
find "$RELEASE" -type f -exec chmod 0644 {} +
if [[ ! -r "$STATE_ROOT/config/users.json" ]]; then
 # Password goes through stdin only: never a command argument or plaintext file.
 printf '%s' "$ADMIN_PASSWORD" | runuser -u dock36 -- env DOCK_PRIVILEGED_HELPER=0 DOCK_DATA_ROOT="$STATE_ROOT/config" DOCK_ADMIN_USER="$ADMIN_USER" "$NODE" "$RELEASE/installer/bootstrap.mjs"
 unset ADMIN_PASSWORD
fi
if [[ -r "$STATE_ROOT/config/users.json" ]]; then
 install -d -m 0700 "$STATE_ROOT/backups"
 cp -a "$STATE_ROOT/config" "$STATE_ROOT/backups/config-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fi
log 5/6 'A configurar pastas privadas e partilha Samba…'
# Keep private homes traversable by their own system users; each individual home is 0700.
chmod 0711 "$STATE_ROOT"
install -d -m 0711 -o root -g root "$STATE_ROOT/homes"
install -d -m 0755 /usr/local/libexec
install -m 0755 -o root -g root "$RELEASE/privileged/36odock-admin.py" /usr/local/libexec/36odock-admin
install -m 0755 -o root -g root "$RELEASE/privileged/36odock-services.py" /usr/local/libexec/36odock-services.py
install -m 0755 -o root -g root "$RELEASE/privileged/36odock-pty.py" /usr/local/libexec/36odock-pty.py
cat > /etc/36odock-helper.json <<HELPER
{"data":"$STATE_ROOT/config","homes":"$STATE_ROOT/homes"}
HELPER
chmod 0600 /etc/36odock-helper.json
cat > "$TMP_DIR/36odock-sudoers" <<'SUDOERS'
# Only the root-owned broker; no arbitrary sudo command or helper arguments.
dock36 ALL=(root) NOPASSWD: /usr/local/libexec/36odock-admin "", /usr/local/libexec/36odock-admin terminal
SUDOERS
visudo -cf "$TMP_DIR/36odock-sudoers"
install -m 0440 -o root -g root "$TMP_DIR/36odock-sudoers" /etc/sudoers.d/36odock
# Existing shared files stay in the old files directory, visible to the administrator only.
if [[ -d "$STATE_ROOT/files" ]]; then chown root:root "$STATE_ROOT/files"; chmod 0700 "$STATE_ROOT/files"; fi
# Initialise an empty include before validating the distro's native Samba configuration.
if [[ ! -e /etc/samba/36odock.conf ]]; then install -m 0600 /dev/null /etc/samba/36odock.conf; fi
if ! grep -qE '^# (DOCK360|36ODOCK) private shares$' /etc/samba/smb.conf; then
 cp -a /etc/samba/smb.conf "$STATE_ROOT/backups/smb.conf-$(date -u +%Y%m%dT%H%M%SZ)-$$"
 printf '\n# DOCK360 private shares\n[global]\n    include = /etc/samba/36odock.conf\n' >> /etc/samba/smb.conf
fi
python3 - "$STATE_ROOT/config/users.json" <<'SYNC'
import json,subprocess,sys
users=json.load(open(sys.argv[1]))
for user in users:
 p=subprocess.run(['/usr/local/libexec/36odock-admin'],input=json.dumps({'op':'provision','username':user['username']}),text=True,capture_output=True,check=True)
 if not json.loads(p.stdout).get('ok'):raise SystemExit('Falhou a criação da pasta privada')
p=subprocess.run(['/usr/local/libexec/36odock-admin'],input=json.dumps({'op':'samba','action':'sync','username':users[0]['username']}),text=True,capture_output=True,check=True)
if not json.loads(p.stdout).get('ok'):raise SystemExit('Falhou a configuração Samba')
SYNC
printf '%s' '{"op":"teams","action":"sync"}' | /usr/local/libexec/36odock-admin | python3 -c 'import json,sys; assert json.load(sys.stdin)["ok"], "Falhou a configuração de equipas"'
testparm -s /etc/samba/smb.conf >/dev/null
systemctl enable --now smbd.service

PREVIOUS=$(readlink "$INSTALL_ROOT/current" || true)
if [[ -r $UNIT ]]; then cp "$UNIT" "$TMP_DIR/previous.service"; fi
ACTIVATED=1
ln -sfn "$RELEASE" "$INSTALL_ROOT/current.next"
mv -Tf "$INSTALL_ROOT/current.next" "$INSTALL_ROOT/current"
cat > "$UNIT" <<SERVICE
$MARKER
[Unit]
Description=DOCK360
After=network-online.target docker.service
Wants=network-online.target
Requires=docker.service

[Service]
Type=simple
User=dock36
Group=dock36
SupplementaryGroups=docker
WorkingDirectory=$INSTALL_ROOT/current
ExecStart=$NODE $INSTALL_ROOT/current/server/server.mjs
Environment=DOCK_HOST=0.0.0.0
Environment=PORT=$PORT
Environment=DOCK_DATA_ROOT=$STATE_ROOT/config
Environment=DOCK_HOMES_ROOT=$STATE_ROOT/homes
Environment=DOCK_TEAMS_ROOT=$STATE_ROOT/teams
Environment=DOCK_PRIVILEGED_HELPER=1
Restart=on-failure
RestartSec=5
UMask=0027
PrivateTmp=true
# The root-owned helper provides the administrative functions through fixed sudo rules.
# Filesystem namespaces and NoNewPrivileges must not block those explicit functions.

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable 36odock.service
systemctl restart 36odock.service
log 6/6 'A verificar o painel…'
READY=0
for ((attempt=0; attempt<20; attempt++)); do
 if systemctl is-active --quiet 36odock.service && curl --fail --silent "http://127.0.0.1:$PORT/api/health" | grep -q '"product":"DOCK360"'; then READY=1; break; fi
 sleep 1
done
if [[ $READY -ne 1 ]]; then journalctl -u 36odock.service -n 20 --no-pager >&2; fail 'O painel não respondeu ao teste HTTP.'; fi
printf '%s\n' "$PORT" > "$INSTALL_ROOT/port"
ACTIVATED=0
IP=$(hostname -I | awk '{print $1}')
printf '\nInstalação concluída.\n\nAbra, num dispositivo da mesma rede: http://%s:%s\n\nO DOCK360 arranca automaticamente quando ligar o Raspberry.\nEstado: sudo systemctl status 36odock\nRegistos: sudo journalctl -u 36odock -n 50 --no-pager\nNão abra a porta no router para a Internet.\n' "${IP:-IP-DO-RASPBERRY}" "$PORT"
